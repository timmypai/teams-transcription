"""Meeting-scoped, default-muted native Live production wiring.

B failure affects only its response branch. A still owns the complete ledger.
No legacy answerer/appendSpeech path is imported or used here.
"""
import asyncio
from pathlib import Path

from .b_browser_tx import BrowserTXSink
from .b_dual_policy import OwnedSenderDualPolicy
from .b_native import build_native_meeting_responder
from .b_response import MeetingStoreMinutesReader
from .meeting_store import MeetingStore
from .qa_activity import QuestionActivityRecorder
from .runtime_guard import RuntimeLiveGuard
from .diagnostics import RESPONSE_START_PHASES, response_start_failure, response_start_receipt, sender_selection_diagnostic, response_progress_diagnostic, response_runtime_failure_receipt


class _AsyncStore:
    def __init__(self, root):
        self.store = MeetingStore(root)

    async def read(self, meeting_id):
        return await asyncio.to_thread(self.store.read,meeting_id)


class ProductionResponseController:
    def __init__(self, session, meeting, browser, config, ice_servers):
        self.session, self.meeting, self.browser = session, meeting, browser
        self.meeting_id, self.config, self.ice_servers = session.ident, config, ice_servers
        self.native = None
        self.state = "starting"
        self.error_code = None
        self._lock = asyncio.Lock()
        self.sink = self.policy = self.frame = None
        self._policy_released = False
        self.startup_phase = 'not_started'
        self.startup_error = None
        self.cleanup_errors = []

    def _cleanup_error(self, phase, exc=None):
        # Keep the first receipt for each of the two fixed cleanup operations.
        if not any(e['phase'] == phase for e in self.cleanup_errors):
            self.cleanup_errors.append(response_start_failure(exc, phase))

    async def _release_policy(self):
        if self.policy is None or self._policy_released:
            return True
        if self.sink._pending or self.sink.started:
            self._cleanup_error('policy_release')
            return False
        try:
            restored = await self.frame.evaluate("""owner => {
                const b=window.__bTXBindings?.get(owner);
                return !!b && b.document===document && b.capture===window.__meeting &&
                  b.meetingId===window.__bMeetingId && b.href===location.href &&
                  b.pc.getSenders().includes(b.sender) && b.sender.track===b.original &&
                  !b.original?.enabled && (b.original!==null ||
                    (b.pc.getTransceivers().includes(b.transceiver) && b.transceiver.sender===b.sender));
            }""", self.sink.owner)
            if restored is not True:
                self._cleanup_error('policy_release')
                return False
            # Already released on a previous idempotent shutdown.
            if self.meeting.dual_policy is None:
                self._policy_released = True
                return True
            self._policy_released = await self.meeting.release_dual_policy(self.frame, self.policy)
            if not self._policy_released:
                self._cleanup_error('policy_release')
            return self._policy_released
        except Exception as exc:
            self._cleanup_error('policy_release', exc)
            return False

    async def start(self):
        try:
            self.startup_phase = 'guard_construct'
            if "allowed_egress_hosts" not in self.config:
                raise ValueError("existing_egress_policy_required")
            host = RuntimeLiveGuard(self.meeting_id, self.config.get("allowed_egress_hosts", []), ice_servers=self.ice_servers)
            self.startup_phase = 'guard_prepare'
            await host.prepare()
            self.startup_phase = 'sender_select'
            frame, peer, sender = await self.meeting.response_sender(self.meeting_id)
            self.startup_phase = 'policy_construct'
            policy = OwnedSenderDualPolicy(frame, self.meeting_id)
            self.startup_phase = 'sink_construct'
            sink = BrowserTXSink(frame, meeting_id=self.meeting_id, peer_index=peer,
                sender_index=sender, dual_channel_policy=policy.authorize,
                selection_id=getattr(self.meeting, '_response_selection_id', None))
            self.frame, self.policy, self.sink = frame, policy, sink
            self.startup_phase = 'sink_bind'
            await sink.bind()
            self.startup_phase = 'policy_check'
            if not await policy.check():
                raise RuntimeError("initial_sender_policy_failed")
            self.startup_phase = 'policy_bind'
            self.meeting.bind_dual_policy(frame, policy)
            self.startup_phase = 'native_construct'
            runtime = Path(self.config.get("runtime_dir", self.session.path))
            reader = MeetingStoreMinutesReader(_AsyncStore(self.session.root))
            self.native = build_native_meeting_responder(self.browser, runtime,
                self.meeting_id, reader, guard=host.adapter(), sink=sink,
                executable=self.config["codex_bin"], ice_servers=self.ice_servers,
                wake_words=("小白小白","xiaobai xiaobai"),prior_context=self.config.get('prior_context'),
                **({'before_native_start':lambda stage:self.session.acceptance_budget.claim('B',stage)}
                    if getattr(self.session,'acceptance_budget',None) is not None else {}),
                activity_recorder=QuestionActivityRecorder(self.session.store, self.meeting_id))
            # Output authorization is exclusively an authenticated control action.
            self.startup_phase = 'native_start'
            await self.native.start(enable_output=False)
            self.startup_phase = 'ready'
            self.state = "sleeping"
            self.session.event("response_ready", {"output_enabled":False,
                "sender_selection":sender_selection_diagnostic(getattr(self.meeting, '_response_sender_diagnostic', None))})
        except asyncio.CancelledError:
            await self.stop()
            raise
        except Exception as exc:
            if self.startup_error is None:
                native_error = getattr(self.native, 'startup_error', None)
                self.startup_error = (response_start_receipt(native_error) if isinstance(native_error, dict)
                    else response_start_failure(exc, self.startup_phase))
            self.error_code = "response_start_failed"
            self.state = "unavailable"
            if self.native:
                try:
                    await self.native.stop()
                except Exception as cleanup_exc:
                    self._cleanup_error('native_stop', cleanup_exc)
                    self.error_code = "response_cleanup_unknown"
            if not await self._release_policy():
                self.error_code = "response_cleanup_unknown"
            if self.error_code == "response_cleanup_unknown":
                self.state = "stop_unknown"
            self.session.event("response_unavailable", {"error_code":self.error_code,
                "startup_error":dict(self.startup_error),
                "sender_selection":sender_selection_diagnostic(getattr(self.meeting, '_response_sender_diagnostic', None)),
                "cleanup_errors":[dict(e) for e in self.cleanup_errors]})
            # No exception body, provider text, URL, token or SDP reaches logs.
            return False
        return True

    def status(self):
        value = self.native.status() if self.native else {}
        phase = getattr(self.native, 'startup_phase', self.startup_phase)
        ready = self.state not in {"unavailable", "starting", "stopped", "stop_unknown"}
        return {"meeting_id":self.meeting_id,
                "state":value.get("state", self.state) if ready else self.state,
                # A failed cleanup/state transition cannot prove physical mute.
                # Keep the provider's actual flags even in stop_unknown. Missing
                # provider evidence is not treated as a successful mute either.
                "output_enabled":value.get("output_enabled", False),
                "output_muted":value.get("output_muted", self.native is None),
                "error_code":self.error_code or ("response_failed" if value.get("error") else None),
                "startup_phase":phase if phase in RESPONSE_START_PHASES else 'unknown',
                "startup_error":dict(self.startup_error) if self.startup_error else None,
                "runtime_failure":response_runtime_failure_receipt(value.get('runtime_failure')),
                "sender_selection":sender_selection_diagnostic(getattr(self.meeting, '_response_sender_diagnostic', None)),
                "progress": response_progress_diagnostic({**value,
                    'fanout': getattr(self.session, 'response_rx_counts', {})}) if self.native else None,
                "cleanup_errors":[dict(e) for e in self.cleanup_errors],
                "question_activity": value.get("question_activity",
                    {"state":"unavailable", "error_code":"question_activity_not_configured"}),
                "native_contract":"v3-host-question",
                "stop_status":value.get("stop_status", "not_started"),
                "cleanup_status":value.get("cleanup_status", "idle")}

    async def enable_output(self):
        async with self._lock:
            if not self.native or self.state != "sleeping" or self.native.error:
                raise RuntimeError("native_response_unavailable")
            self.native.enable_output()
            return self.status()

    async def disable_output(self):
        async with self._lock:
            if self.native:
                await self.native.disable_output()
            return self.status()

    def push_rx(self, pcm, *, started_at, ended_at):
        if self.native and self.state == "sleeping":
            try:
                return self.native.push_rx(self.meeting_id, pcm, started_at=started_at, ended_at=ended_at)
            except Exception:
                self.error_code = "response_rx_failed"
        return False

    async def stop(self):
        async with self._lock:
            if not self.native:
                if not await self._release_policy():
                    self.error_code = "response_cleanup_unknown"
                if self.error_code == "response_cleanup_unknown":
                    self.state = "stop_unknown"
                    return "unknown"
                self.state = "stopped"
                return "not_started"
            try:
                result = await self.native.stop()
            except BaseException as exc:
                self._cleanup_error('native_stop', exc)
                self.state = "stop_unknown"
                self.error_code = "response_cleanup_unknown"
                raise
            if not await self._release_policy():
                self.state = "stop_unknown"
                self.error_code = "response_cleanup_unknown"
                return "unknown"
            self.state = "stopped" if result in {"stopped", "not_started"} else "stop_unknown"
            return result
