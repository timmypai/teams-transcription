"""Read-only calendar and meeting workspace projections of authoritative SQLite data."""
import json
import re
from datetime import date, datetime, time, timezone as utc_timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


# Listing deliberately never joins source, summary or Q&A text tables.
_MEETINGS = '''SELECT o.*, s.name AS series_name,
    (NULLIF(json_extract(o.value,'$.recurring_event_id'),'') IS NOT NULL
     OR NULLIF(json_extract(o.value,'$.series_id'),'') IS NOT NULL
     OR s.series_key != o.identity_key
     OR EXISTS (SELECT 1 FROM calendar_occurrences sibling
                WHERE sibling.series_id=o.series_id AND sibling.id!=o.id)) AS grouped,
    r.session_id, r.state AS run_state, rt.status_json,
    l.state AS lease_state, l.boot_id, l.expires_boottime
    FROM calendar_occurrences o JOIN meeting_series s ON s.id=o.series_id
    LEFT JOIN assistant_runs r ON r.occurrence_id=o.id
    LEFT JOIN session_runtime rt ON rt.meeting_id=r.session_id
    LEFT JOIN execution_leases l ON l.lease_id=r.session_id AND l.kind='capture' '''

_STATE_LABELS = {
    'pending':'未開始', 'needs_review':'待確認', 'cancelled':'已取消', 'skipped':'已略過',
    'running':'執行中', 'starting':'啟動中', 'preparing':'準備中', 'joining':'加入中',
    'connecting':'連線中', 'waiting_for_admission':'等待准入', 'joined':'已加入',
    'prepared':'準備完成', 'owner_confirmed':'已確認', 'rx_starting':'啟動收音中',
    'recording':'記錄中', 'draining':'停止整理中', 'stopped':'已停止',
    'completed':'已結束', 'failed':'執行失敗', 'interrupted':'執行中斷',
    'recorded_without_transcript':'已結束，沒有逐字來源', 'recorded':'已結束',
    'worker_lost':'執行狀態待確認',
}


def _zone(name):
    from .assistant_store import AssistantStoreError
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, TypeError):
        raise AssistantStoreError('invalid_timezone') from None


def _instant(value):
    if not isinstance(value,str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace('Z','+00:00'))
        return parsed if parsed.tzinfo is not None else None
    except ValueError:
        return None


def _range(start, end, zone):
    from .assistant_store import AssistantStoreError
    try:
        if any(not isinstance(value,str) or re.fullmatch(r'\d{4}-\d{2}-\d{2}',value) is None
                for value in (start,end)):
            raise ValueError
        first, last = date.fromisoformat(start),date.fromisoformat(end)
        if last<=first:
            raise ValueError
        return tuple(datetime.combine(day,time.min,zone).astimezone(utc_timezone.utc).isoformat()
            for day in (first,last))
    except (ValueError, OverflowError):
        raise AssistantStoreError('invalid_calendar_range') from None


def _meeting(store, row, zone):
    value = json.loads(row['value'])
    status = json.loads(row['status_json']) if row['status_json'] else {}
    active = bool(row['run_state']=='running' and row['lease_state']=='active'
        and store._lease_time_valid(row))
    state = row['run_state'] or row['state']
    if active:
        state = status.get('state') or 'starting'
    label = _STATE_LABELS.get(state,'狀態待確認')
    if row['run_state']=='running' and not active:
        label = '執行狀態待確認'
    result = dict(id=row['id'],title=value.get('title') or '未命名會議',
        kind='series' if row['grouped'] else 'single',series_id=row['series_id'],
        series_name=row['series_name'],state=state,state_label=label,
        session_id=row['session_id'],is_live=bool(active and state=='recording'))
    for edge in ('start','end'):
        instant = _instant(row[edge+'_at'])
        local = instant.astimezone(zone) if instant else None
        result[edge+'_at'] = local.isoformat() if local else None
        result[edge+'_date'] = local.date().isoformat() if local else None
        result[edge+'_time'] = local.strftime('%H:%M') if local and not value.get('all_day') else None
    return result


def calendar_view(store, start, end, timezone):
    zone = _zone(timezone)
    first, last = _range(start,end,zone)
    with store._locked() as db:
        rows = db.execute(_MEETINGS + '''WHERE julianday(o.start_at)<julianday(?)
            AND (julianday(o.end_at)>julianday(?) OR
                 (o.end_at IS NULL AND julianday(o.start_at)>=julianday(?)))
            ORDER BY julianday(o.start_at),o.id''',(last,first,first))
        meetings = [_meeting(store,row,zone) for row in rows]
        series = {item['series_id']:item['series_name'] for item in meetings if item['kind']=='series'}
        undated = db.execute('SELECT COUNT(*) FROM calendar_occurrences WHERE start_at IS NULL').fetchone()[0]
    return dict(meetings=meetings,series=[dict(id=ident,name=name) for ident,name in
        sorted(series.items(),key=lambda item:(item[1],item[0]))],undated_count=undated)


def _previous(store, db, row, run, zone):
    # Once a run starts, its frozen snapshot is exactly the history B received.
    prior = (json.loads(run['prior_json']) if run else
        store._prior_db(db,row['series_id'],row['start_at']) if row['start_at'] else {})
    if not prior.get('available') or prior.get('series_id')!=row['series_id']:
        return None
    earlier = db.execute('''SELECT o.id,o.value,o.start_at FROM assistant_runs r
        JOIN calendar_occurrences o ON o.id=r.occurrence_id
        WHERE r.session_id=? AND o.series_id=?''',
        (prior.get('session_id'),row['series_id'])).fetchone()
    if earlier is None:
        return None
    summary = prior['summary']
    occurred = _instant(prior.get('occurred_at') or earlier['start_at'])
    return dict(session_id=prior['session_id'],occurrence_id=earlier['id'],
        title=json.loads(earlier['value']).get('title') or '未命名會議',
        date=occurred.astimezone(zone).date().isoformat() if occurred else None,
        conclusions=[dict(text=item['text'],sources=item.get('sources',[]))
            for item in (summary.get('決策') or summary.get('重點') or [])],summary=summary)



def _controls(store, db, row, meeting, status, job):
    value = json.loads(row['value'])
    calendar = db.execute('SELECT value FROM assistant_calendars WHERE id=?',(row['calendar_ref'],)).fetchone()
    policy = json.loads(calendar['value']) if calendar else None
    authorized = bool(value.get('recording_authorized') and
        (not row['calendar_ref'] or policy and policy.get('enabled') and policy.get('recording_authorized')))
    start, end = _instant(row['start_at']),_instant(row['end_at'])
    now = datetime.now(utc_timezone.utc).timestamp()
    join_window = bool(start and end and end.timestamp()>now
        and start.timestamp()-value.get('join_early_seconds',0)<=now
        and now<=start.timestamp()+value.get('max_lateness_seconds',0))
    busy = db.execute("SELECT 1 FROM execution_leases WHERE kind='capture' AND state='active' LIMIT 1").fetchone()
    stopping = db.execute('SELECT 1 FROM session_stop_requests WHERE meeting_id=?',(row['session_id'],)).fetchone()
    active = bool(row['run_state']=='running' and row['lease_state']=='active'
        and store._lease_time_valid(row) and not stopping and
        meeting['state'] not in {'stopped','completed','failed','draining','recorded','recorded_without_transcript'})
    response = status.get('response_status')
    speaking = (policy.get('enabled') and policy.get('recording_authorized') and policy.get('speaking_authorized')
        if policy else not row['calendar_ref'] and authorized and value.get('speaking_authorized'))
    return dict(
        join=bool(row['state']=='pending' and not row['session_id'] and authorized and join_window
            and value.get('link_status')=='valid' and not value.get('all_day')
            and not busy and not store._capture_interlocks_db(db)),
        skip=bool(not row['session_id'] and row['state'] in {'pending','needs_review'}),
        stop=active,
        output=bool(active and isinstance(response,dict) and response.get('state') not in {'failed','stopped'}
            and (speaking or response.get('output_enabled'))),
        retry_summary=False)


def _latest(values):
    instants = [(instant,value) for value in values if (instant := _instant(value)) is not None]
    return max(instants,key=lambda item:item[0])[1] if instants else None


def meeting_view(store, occurrence_id, timezone):
    from .assistant_store import AssistantStoreError
    zone = _zone(timezone)
    with store._locked() as db:
        row = db.execute(_MEETINGS+'WHERE o.id=?',(occurrence_id,)).fetchone()
        if row is None:
            raise AssistantStoreError('record_not_found')
        meeting = _meeting(store,row,zone)
        session_id = row['session_id']
        run = db.execute('SELECT * FROM assistant_runs WHERE session_id=?',(session_id,)).fetchone() if session_id else None
        status = json.loads(row['status_json']) if row['status_json'] else {}
        source = store._publish(db,session_id,materialize=True) if session_id else None
        job = db.execute('SELECT state,error_code,updated_at FROM summary_jobs WHERE session_id=? '
            'ORDER BY created_at DESC,rowid DESC LIMIT 1',(session_id,)).fetchone() if session_id else None
        previous = _previous(store,db,row,run,zone)
        tasks = [{key:task[key] for key in ('id','text','owner','date','status','origin_session_id')}
            for task in store._tasks_db(db,row['series_id'])]
        series_meetings = ([_meeting(store,other,zone) for other in db.execute(
            _MEETINGS+'WHERE o.series_id=? ORDER BY julianday(o.start_at),o.id',(row['series_id'],))]
            if meeting['kind']=='series' else [])
        # Keep canonical source IDs, provenance and grouped stream order;
        # the calendar workspace only selects its display fields.
        transcript = [dict(id=entry['id'],text=entry['text'],timestamp=entry.get('timestamp'),
            source_state=entry['source_state'],quality=entry.get('quality'),
            revision=entry.get('revision',entry.get('source_revision')) or 0)
            for entry in source['sources']] if source else []
        snapshot = status.get('response_status')
        response = (dict(state=snapshot.get('state','unknown'),output_enabled=bool(snapshot.get('output_enabled')),
            output_muted=bool(snapshot.get('output_muted',True)),error_code=snapshot.get('error_code'))
            if isinstance(snapshot,dict) else None)
        if response is not None and isinstance(snapshot.get('question_activity'),dict):
            response['question_activity'] = {key:snapshot['question_activity'].get(key)
                for key in ('state','error_code')}
        detail = dict(meeting=meeting,session_id=session_id,run_state=row['run_state'],
            response=response,previous=previous,tasks=tasks,series_meetings=series_meetings,
            transcript=transcript,summary=source['summary'] if source else None,
            summary_job=dict(state=job['state'],error_code=job['error_code']) if job else None,
            source_version=source['version'] if source else None,
            completeness=source['completeness'] if source else None,
            controls=_controls(store,db,row,meeting,status,job),
            cleanup_review_required=bool(run and store._cleanup_review_metadata(
                db,run,row['status_json'],worker_status='unknown')['required']))
        observed = [status.get('updated_at'),status.get('created_at'),
            run['started_at'] if run else None,run['ended_at'] if run else None,
            job['updated_at'] if job else None]
        observed.extend(item['timestamp'] for item in transcript)
    # Public journal API owns legacy handling and association. Never synthesize
    # Q&A from transcript text; the separate lock also avoids nested flock.
    detail['qa'] = store.list_question_activity(session_id) if session_id else []
    observed.extend(item['updated_at'] for item in detail['qa'])
    detail['updated_at'] = _latest(observed)
    return detail
