"""Revocable native-track output; only scalar receiver observations leave Chromium."""
import asyncio
import contextlib
import math
import time

from .b_audio import PCM_ACTIVITY_RMS_THRESHOLD, PulseTXSink
from .diagnostics import response_start_failure, response_start_receipt


class NativeTrackOutput:
    """One persistent relay, with per-question permission and local quiet evidence."""

    def __init__(self, meeting_id, sink, *, clock=time.monotonic):
        self.meeting_id, self.sink, self.clock = meeting_id, sink, clock
        self.enabled = self.active = self.closed = False
        self.frames = self.activity_frames = 0
        self._source_activity_frames = 0
        self.received_duration = self.received_energy = self.quiet_received_seconds = 0.0
        self.last_active = 0.0
        self.connected = False
        self.last_delivery = None
        self._previous = None
        self._lock = asyncio.Lock()
        self._startup_step = 'output_scope'
        self.startup_error = None

    @property
    def startup_step(self):
        return getattr(self.sink, 'startup_step', None) if self._startup_step == 'relay_attach' else self._startup_step

    @property
    def quiet_received_seconds(self):
        return min(self._source_quiet_seconds, self._render_quiet_seconds)

    @quiet_received_seconds.setter
    def quiet_received_seconds(self, seconds):
        # A new provider turn invalidates both tails through the existing API.
        self._source_quiet_seconds = self._render_quiet_seconds = seconds

    async def attach_live(self, page):
        self._startup_step = 'output_scope'
        try:
            if self.closed or self.active:
                raise RuntimeError("Native output unavailable")
            self._startup_step = 'relay_attach'
            await self.sink.attach_live(page)
            self._startup_step = 'sender_install'
            await self.sink.start()
            self._startup_step = 'initial_mute'
            await self.sink.set_muted(True)
        except BaseException as exc:
            if self.startup_error is None:
                relay_error = getattr(self.sink, 'startup_error', None) if self._startup_step in {'relay_attach','sender_install'} else None
                self.startup_error = response_start_receipt(relay_error) if isinstance(relay_error, dict) else \
                    response_start_failure(exc, 'native_output_attach', output_step=self.startup_step)
            raise

    def start_output(self):
        if self.closed or self.active:
            raise RuntimeError("Output is closed or speech is active")
        self.enabled = True

    async def _sample(self):
        sample = await self.sink.observe()
        if not isinstance(sample, dict) or sample.get('connected') is not True:
            raise RuntimeError("Native relay disconnected")
        for key in ('frames', 'packets', 'energy', 'duration',
                    'source_frames', 'source_packets', 'source_energy', 'source_duration'):
            value = sample.get(key)
            if (isinstance(value, bool) or not isinstance(value, (int, float))
                    or not math.isfinite(value) or value < 0):
                raise RuntimeError("Invalid native relay observation")
            if self._previous is not None and value < self._previous[key]:
                raise RuntimeError("Native relay observation reset")
        self.connected = True
        return sample

    async def begin_speech(self, meeting_id):
        if meeting_id != self.meeting_id:
            raise ValueError("Invalid output scope")
        async with self._lock:
            if self.closed or self.active:
                raise RuntimeError("Output unavailable or busy")
            self.frames = self.activity_frames = 0
            self._source_activity_frames = 0
            self.received_duration = self.received_energy = self.quiet_received_seconds = 0.0
            self.last_active = 0.0
            self.last_delivery = None
            try:
                self._previous = await self._sample()
                self.active = True
                if self.enabled:
                    await self.sink.set_muted(False)
            except BaseException as exc:
                self.active = False
                if not isinstance(exc, asyncio.CancelledError):
                    self.enabled = False
                with contextlib.suppress(Exception):
                    await PulseTXSink._finish_cleanup(self.sink.pause())
                raise

    async def observe(self):
        async with self._lock:
            if not self.active or self.closed:
                raise RuntimeError("Native output lease inactive")
            try:
                sample = await self._sample()
                previous, self._previous = self._previous, sample
                frames = sample['frames'] - previous['frames']
                duration = sample['duration'] - previous['duration']
                energy = sample['energy'] - previous['energy']
                source_frames = sample['source_frames'] - previous['source_frames']
                source_duration = sample['source_duration'] - previous['source_duration']
                source_energy = sample['source_energy'] - previous['source_energy']
                source_packets = sample['source_packets'] - previous['source_packets']
                self.frames += frames
                self.received_duration += duration
                self.received_energy += energy
                # Only real decoded input extends source quiet; native render
                # underflow zeros are not evidence that the provider went quiet.
                if source_packets > 0 and source_frames > 0 and source_duration > 0:
                    rms = math.sqrt(source_energy / source_duration) * 32768
                    if rms >= PCM_ACTIVITY_RMS_THRESHOLD:
                        self._source_activity_frames += source_frames
                        self._source_quiet_seconds = 0.0
                    elif self._source_activity_frames > 0:
                        self._source_quiet_seconds += source_duration
                # Playout can lag input. Its voice resets only its own tail, and
                # its quiet can finish after real source packets stop arriving.
                if frames > 0 and duration > 0:
                    rms = math.sqrt(energy / duration) * 32768
                    if rms >= PCM_ACTIVITY_RMS_THRESHOLD:
                        self.activity_frames += frames
                        self.last_active = self.clock()
                        self._render_quiet_seconds = 0.0
                    elif self.activity_frames > 0:
                        self._render_quiet_seconds += duration
                return (self._source_activity_frames > 0 and self.activity_frames > 0
                        and self.quiet_received_seconds >= .8)
            except BaseException as exc:
                self.active = False
                if not isinstance(exc, asyncio.CancelledError):
                    self.connected = self.enabled = False
                with contextlib.suppress(Exception):
                    await PulseTXSink._finish_cleanup(self.sink.pause())
                raise

    async def end_speech(self, *, quiet=False):
        async with self._lock:
            was_active, self.active = self.active, False
            if was_active:
                try:
                    await PulseTXSink._finish_cleanup(self.sink.pause())
                except BaseException as exc:
                    if not isinstance(exc, asyncio.CancelledError):
                        self.enabled = False
                    raise
                self.last_delivery = {
                    'status': 'quiet' if quiet else 'stopped',
                    'truncated': False, 'drained': False, 'reason': None}
            return dict(self.last_delivery or {
                'status': 'idle', 'truncated': False, 'drained': False, 'reason': None})

    async def stop_output(self):
        self.enabled = False
        return await self.end_speech()

    async def close(self):
        self.closed = True
        try:
            await self.stop_output()
        finally:
            await PulseTXSink._finish_cleanup(self.sink.stop())
