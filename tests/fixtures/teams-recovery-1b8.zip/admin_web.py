"""Private server-rendered management; no request-owned meeting execution."""
import asyncio
import base64
import hashlib
import hmac
import html
import json
import os
import re
import secrets
import stat
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, RedirectResponse, PlainTextResponse, Response
from starlette.routing import Route

from .assistant_store import AssistantStoreError
from .calendar_client import CalendarError
from .meeting_store import TERMINAL
from .admin_ui import calendar_page, page as management_page


class AdminError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def _private_read(path, maximum):
    path = Path(path)
    try:
        if path.absolute()!=path.resolve() or path.is_symlink():
            raise ValueError()
        fd = os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
        with os.fdopen(fd,'rb') as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077:
                raise ValueError()
            value = stream.read(maximum+1)
        if len(value)>maximum:
            raise ValueError()
        return value
    except (OSError,ValueError):
        raise AdminError('private_admin_credentials_required') from None


def password_record(password):
    if not isinstance(password,str) or not 12<=len(password)<=1024:
        raise AdminError('admin_password_length_invalid')
    salt = secrets.token_bytes(32)
    digest = hashlib.scrypt(password.encode(),salt=salt,n=32768,r=8,p=1,dklen=64,maxmem=64*1024*1024)
    return {'algorithm':'scrypt','n':32768,'r':8,'p':1,'salt':base64.b64encode(salt).decode(),
        'hash':base64.b64encode(digest).decode()}


def initialize_admin_credentials(settings, password):
    """Explicit operator bootstrap, never overwrite existing credentials."""
    record = password_record(password)
    paths = [Path(settings.admin_password_file),Path(settings.admin_session_secret_file)]
    for path in paths:
        if path.exists() or path.is_symlink():
            raise AdminError('admin_credentials_already_exist')
        if path.parent.is_symlink() or path.parent.absolute()!=path.parent.resolve():
            raise AdminError('private_admin_directory_required')
        path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        if path.parent.stat().st_uid!=os.getuid() or path.parent.stat().st_mode&0o077:
            raise AdminError('private_admin_directory_required')
    created = []
    try:
        for path,value in zip(paths,[(json.dumps(record)+'\n').encode(),base64.b64encode(secrets.token_bytes(32))+b'\n']):
            fd = os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
            created.append(path)
            with os.fdopen(fd,'wb') as stream:
                stream.write(value)
                stream.flush()
                os.fsync(stream.fileno())
        for parent in {path.parent for path in paths}:
            fd = os.open(parent,os.O_RDONLY|os.O_DIRECTORY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
    except BaseException:
        for path in created:
            path.unlink(missing_ok=True)
        raise
    return {'admin_initialized':True}


class AdminSessions:
    cookie = 'assistant_session'

    def __init__(self, settings, clock=time.time):
        self.settings,self.clock = settings,clock
        try:
            self.password = json.loads(_private_read(settings.admin_password_file,4096))
            expected = {'algorithm','n','r','p','salt','hash'}
            if (set(self.password)!=expected or self.password['algorithm']!='scrypt'
                    or (self.password['n'],self.password['r'],self.password['p'])!=(32768,8,1)):
                raise ValueError()
            self.salt = base64.b64decode(self.password['salt'],validate=True)
            self.digest = base64.b64decode(self.password['hash'],validate=True)
            self.secret = base64.b64decode(_private_read(settings.admin_session_secret_file,256).strip(),validate=True)
            if (len(self.salt),len(self.digest),len(self.secret))!=(32,64,32):
                raise ValueError()
        except (ValueError,TypeError,KeyError):
            raise AdminError('private_admin_credentials_required') from None
        self.sessions,self.attempts = {},{}

    def _signed(self, nonce):
        return nonce+'.'+hmac.new(self.secret,nonce.encode(),'sha256').hexdigest()

    def lookup(self, token):
        now = self.clock()
        self.sessions = {key:value for key,value in self.sessions.items() if value['expires_at']>now}
        if not isinstance(token,str) or not re.fullmatch(r'[a-f0-9]{64}\.[a-f0-9]{64}',token):
            return None
        nonce = token.split('.',1)[0]
        if not hmac.compare_digest(token,self._signed(nonce)):
            return None
        return self.sessions.get(nonce)

    def create(self, authenticated=False):
        if len(self.sessions)>=1024:
            oldest = min(self.sessions,key=lambda key:self.sessions[key]['expires_at'])
            del self.sessions[oldest]
        nonce = secrets.token_hex(32)
        value = {'nonce':nonce,'authenticated':authenticated,'csrf':secrets.token_hex(32),
            'expires_at':self.clock()+self.settings.admin_session_seconds,'oauth':None}
        self.sessions[nonce] = value
        return value

    def remove(self, session):
        self.sessions.pop(session['nonce'],None)

    def set_cookie(self, response, session):
        response.set_cookie(self.cookie,self._signed(session['nonce']),max_age=self.settings.admin_session_seconds,
            httponly=True,secure=self.settings.cookie_secure,samesite='lax',path='/')

    async def verify_password(self, password, address):
        now = self.clock()
        self.attempts = {key:[stamp for stamp in values if stamp>now-600] for key,values in self.attempts.items()
            if any(stamp>now-600 for stamp in values)}
        if address not in self.attempts and len(self.attempts)>=1024:
            raise AdminError('login_rate_limited')
        attempts = self.attempts.setdefault(address,[])
        if len(attempts)>=10:
            raise AdminError('login_rate_limited')
        attempts.append(now)
        if not isinstance(password,str) or len(password)>1024:
            return False
        digest = await asyncio.to_thread(hashlib.scrypt,password.encode(),salt=self.salt,n=32768,r=8,p=1,
            dklen=64,maxmem=64*1024*1024)
        return hmac.compare_digest(digest,self.digest)




def h(value):
    return html.escape(str(value if value is not None else ''),quote=True)


def hidden(name,value):
    return '<input type="hidden" name="'+h(name)+'" value="'+h(value)+'">'


def input_field(name,label,value='',kind='text'):
    return '<label>'+h(label)+' <input type="'+h(kind)+'" name="'+h(name)+'" value="'+h(value)+'"></label>'


def checkbox(name,label,checked=False):
    return '<label><input type="checkbox" name="'+h(name)+'"'+(' checked' if checked else '')+'>'+h(label)+'</label>'


def select_field(name,label,choices,value=''):
    return '<label>'+h(label)+' <select name="'+h(name)+'">'+''.join('<option value="'+h(key)+'"'+
        (' selected' if str(key)==str(value) else '')+'>'+h(caption)+'</option>' for key,caption in choices)+'</select></label>'


def form(session,action,body,label='保存',path=None):
    target = path or '/actions/'+action
    return '<form method="post" action="'+h(target)+'">'+hidden('csrf',session['csrf'])+body+'<button>'+h(label)+'</button></form>'


def control(session,action,target,label,**values):
    return form(session,action,hidden('id',target)+''.join(hidden(key,value) for key,value in values.items()),label)


def page(title,body,session=None,*,active='settings'):
    return management_page(title,body,session,active=active)


async def bounded_form(request):
    if request.headers.get('content-type','').split(';',1)[0].lower()!='application/x-www-form-urlencoded':
        raise AdminError('unsupported_form_content_type')
    data = bytearray()
    async for chunk in request.stream():
        data.extend(chunk)
        if len(data)>65536:
            raise AdminError('request_too_large')
    try:
        parsed = parse_qs(data.decode('utf-8'),keep_blank_values=True,max_num_fields=64,strict_parsing=True)
        if any(len(values)!=1 for values in parsed.values()):
            raise ValueError()
        return {key:values[0] for key,values in parsed.items()}
    except (ValueError,UnicodeError):
        raise AdminError('invalid_form') from None


def integer(values,key,default=0):
    try:
        return int(values.get(key,str(default)))
    except (ValueError,TypeError):
        raise AdminError('invalid_form_integer') from None


class AdminGuard:
    def __init__(self, app, *, sessions, settings):
        self.app,self.sessions,self.settings = app,sessions,settings

    async def __call__(self, scope, receive, send):
        if scope['type']!='http':
            return await self.app(scope,receive,send)
        request = Request(scope,receive)
        host = request.headers.get('host','')
        try:
            hostname = urlsplit('http://'+host).hostname
        except ValueError:
            hostname = None
        allowed = {'localhost','127.0.0.1','::1'}
        if self.settings.public_base_url:
            allowed.add(urlsplit(self.settings.public_base_url).hostname)
        if hostname not in allowed:
            return await PlainTextResponse('untrusted_host',status_code=400)(scope,receive,send)
        if len(scope.get('query_string',b''))>16384:
            return await PlainTextResponse('request_too_large',status_code=413)(scope,receive,send)
        try:
            if int(request.headers.get('content-length','0'))>65536:
                return await PlainTextResponse('request_too_large',status_code=413)(scope,receive,send)
        except ValueError:
            return await PlainTextResponse('invalid_content_length',status_code=400)(scope,receive,send)
        session = self.sessions.lookup(request.cookies.get(self.sessions.cookie))
        scope.setdefault('state',{})['admin_session'] = session
        async def headers(message):
            if message['type']=='http.response.start':
                message.setdefault('headers',[]).extend([
                    (b'cache-control',b'no-store'),(b'pragma',b'no-cache'),(b'x-content-type-options',b'nosniff'),
                    (b'referrer-policy',b'strict-origin'),(b'x-frame-options',b'DENY'),
                    (b'content-security-policy',b"default-src 'none'; script-src 'self'; connect-src 'self'; style-src 'self' 'unsafe-inline'; form-action 'self' https://accounts.google.com; base-uri 'none'; frame-ancestors 'none'")])
            await send(message)
        await self.app(scope,receive,headers)


def _local_meeting_time(value, timezone_name):
    """Native datetime-local controls use the configured meeting timezone."""
    try:
        parsed = datetime.fromisoformat(value.replace('Z','+00:00'))
        zone = ZoneInfo(timezone_name)
    except (AttributeError, TypeError, ValueError, ZoneInfoNotFoundError):
        raise AdminError('invalid_timestamp') from None
    if parsed.tzinfo is not None:
        return parsed.isoformat()
    candidates = {}
    for fold in (0,1):
        aware = parsed.replace(tzinfo=zone,fold=fold)
        if aware.astimezone(timezone.utc).astimezone(zone).replace(tzinfo=None)==parsed:
            candidates[aware.utcoffset()] = aware
    if len(candidates)!=1:
        raise AdminError('ambiguous_local_time' if candidates else 'invalid_local_time')
    return next(iter(candidates.values())).isoformat()


def create_admin_app(daemon, settings, *, local_teams_control=False):
    sessions = AdminSessions(settings)
    from .meeting_store import MeetingStoreError
    from .rx_contract import RxContractError

    def authenticated(request):
        session = request.state.admin_session
        if not session or not session['authenticated']:
            raise AdminError('admin_login_required')
        return session

    async def submitted(request, *, login=False):
        session = request.state.admin_session
        if session is None or not login and not session['authenticated']:
            raise AdminError('admin_login_required')
        origin = settings.public_base_url.rstrip('/') if settings.public_base_url else str(request.base_url).rstrip('/')
        supplied = request.headers.get('origin')
        referer = request.headers.get('referer')
        if supplied is not None and supplied!=origin:
            raise AdminError('admin_origin_rejected')
        if supplied is None:
            parsed = urlsplit(referer or '')
            if not referer or parsed.scheme+'://'+parsed.netloc!=origin:
                raise AdminError('admin_origin_rejected')
        values = await bounded_form(request)
        csrf = values.pop('csrf','')
        if not re.fullmatch('[a-f0-9]{64}',csrf) or not hmac.compare_digest(csrf,session['csrf']):
            raise AdminError('admin_csrf_rejected')
        return session,values

    async def login(request):
        if request.method=='GET':
            session = request.state.admin_session
            if session and session['authenticated']:
                return RedirectResponse('/',status_code=303)
            session = session or sessions.create()
            response = page('管理登入','<section><p>使用操作者初始化的管理密碼。</p>'+form(session,'',
                input_field('password','管理密碼',kind='password'),'登入',path='/login')+'</section>',session)
            sessions.set_cookie(response,session)
            return response
        session,values = await submitted(request,login=True)
        if set(values)!={'password'}:
            raise AdminError('invalid_form')
        address = request.client.host if request.client else 'unknown'
        if not await sessions.verify_password(values['password'],address):
            response = page('登入失敗','<p class="error">密碼不正確，請重新登入。</p><a href="/login">重新登入</a>',session)
            response.status_code = 401
            return response
        sessions.remove(session)
        authenticated_session = sessions.create(True)
        response = RedirectResponse('/',status_code=303)
        sessions.set_cookie(response,authenticated_session)
        await asyncio.to_thread(daemon.store.audit_control,'admin','admin_login','admin')
        return response

    async def logout(request):
        session,_ = await submitted(request)
        sessions.remove(session)
        response = RedirectResponse('/login',status_code=303)
        response.delete_cookie(sessions.cookie,path='/')
        return response

    async def dashboard(request):
        session = authenticated(request)
        return calendar_page(session,settings.timezone,
            initial_occurrence_id=request.query_params.get('meeting'))

    async def diagnostics(request):
        session = authenticated(request)
        status = daemon.status()
        policy = await asyncio.to_thread(daemon.store.settings)
        jobs = await asyncio.to_thread(daemon.store.list_summary_jobs)
        body = '<section><p>排程：<span class="status">'+('暫停' if policy['scheduler_paused'] else '啟用')+'</span></p>'
        body += '<p>Google：'+h(status['google'].get('error_code') or ('已授權' if status['google'].get('authorized') else '未授權'))+'</p>'
        body += '<p>背景工作：'+h(status['background_task_count'])+'；最後輪詢：'+h(status['last_poll_at'])+'</p>'
        body += '<p class="error">'+h(status['last_error'])+'</p>'
        if status['capture_interlock']:
            body += '<p class="error">Capture 清理待確認；禁止新的入會。摘要恢復仍可執行。</p>'
        body += ('<div class="controls">'+control(session,'scheduler','settings','暫停排程',paused='true')+
            control(session,'scheduler','settings','啟用排程',paused='false')+form(session,'poll','','立即輪詢')+'</div></section>')
        if status['active_session_id']:
            run = await asyncio.to_thread(daemon.store.get_run,status['active_session_id'])
            body += '<section><h2>本場執行</h2><p>'+h(run['occurrence']['title'])+'</p><p>'+h(run['status'].get('state'))+'</p>'
            body += '<p>RX ready：'+h(run['status'].get('rx_ready'))+'；清理：'+h(run['status'].get('cleanup_status'))+'</p>'
            response = status.get('response')
            if response is not None:
                visible = {key:response.get(key) for key in
                    ('state','error_code','startup_phase','output_enabled','output_muted','progress')}
                body += '<h3>語音 B</h3><pre>'+h(json.dumps(visible,ensure_ascii=False,indent=2))+'</pre>'
            body += ('<div class="controls">'+control(session,'stop',run['session_id'],'停止入會')+
                control(session,'output',run['session_id'],'靜音',enabled='false')+
                control(session,'output',run['session_id'],'授權發聲',enabled='true')+'</div>')
            body += '<a href="/history/'+h(run['session_id'])+'">來源與摘要</a></section>'
        body += '<section><h2>歷史摘要工作（服務已停用）</h2><table><tr><th>來源 session</th><th>狀態</th><th>錯誤</th></tr>'
        for job in jobs:
            body += ('<tr><td><a href="/history/'+h(job['session_id'])+'">'+h(job['session_id'])+'</a></td><td>'+h(job['state'])+
                '</td><td>'+h(job['error_code'])+'</td></tr>')
        return page('進階診斷',body+'</table></section>',session)

    async def settings_page(request):
        session = authenticated(request)
        status = daemon.status()
        policy = await asyncio.to_thread(daemon.store.settings)
        calendars = await asyncio.to_thread(daemon.store.list_calendars)
        rows = calendars+[{'account_id':'default','calendar_id':'primary','name':'','enabled':False,
            'recording_authorized':False,'speaking_authorized':False,'join_early_seconds':60,'max_lateness_seconds':300}]
        body = ('<section><h2>自動加入會議</h2><p>目前'+
            ('已暫停' if policy['scheduler_paused'] else '已啟用')+
            '。只會加入已授權且符合時間的會議；暫停排程不會停止正在進行的會議。</p>'+
            '<div class="controls">'+control(session,'scheduler','settings','暫停排程',paused='true')+
            control(session,'scheduler','settings','啟用排程',paused='false')+
            form(session,'poll','','更新行事曆')+'</div></section>')
        if status['capture_interlock']:
            body += '<section><h2>上次離會需要確認</h2><p>請先確認助理已離會，再恢復新的入會。</p><a href="/history">查看受阻會議與清理確認</a></section>'
        body += ('<section><h2>Google 行事曆</h2><p>'+
            ('已連接' if status['google'].get('authorized') and not status['google'].get('error_code') else '尚未連接，或需要重新授權')+
            '。連接日曆不代表已取得錄音或發聲同意；仍可使用 Teams 連結手動安排會議。</p>'+
            form(session,'','','連接 Google Calendar',path='/google/connect')+'</section>')
        provider=status.get('provider') or {}
        account={'unchecked':'尚未檢查','blocked':'需要檢查授權或提供者連線',
            'admissible_unverified':'已辨識 ChatGPT 帳號；音訊尚未驗證'}.get(provider.get('provider_status'),'尚未檢查')
        body += ('<section><h2>ChatGPT／GPT Live 授權</h2><p>帳號檢查：'+h(account)+
            '。管理密碼、Google 連線及 Teams 登入都不是 ChatGPT 授權。</p>'+
            '<p>本人首次授權或重新登入需在不錄製、停用容器日誌的私有互動終端完成；此頁不接收一次性代碼、token 或 ChatGPT 密碼。'+
            '授權保留在同一部署的私有持久目錄；登入成功仍須另外驗證 GPT Live 音訊收發。</p></section>')
        for calendar in rows:
            fields = ''.join(hidden(key,calendar[key]) for key in ('id','revision') if key in calendar)
            fields += (input_field('account_id','資料帳號範圍',calendar['account_id'])+
                input_field('calendar_id','Google Calendar ID',calendar['calendar_id'])+input_field('name','名稱',calendar['name']))
            fields += (checkbox('enabled','啟用此 Calendar',calendar['enabled'])+
                checkbox('recording_authorized','已取得加入及錄音授權',calendar['recording_authorized'])+
                checkbox('speaking_authorized','已授權此 Calendar 場次由小白發聲',calendar['speaking_authorized']))
            fields += (input_field('join_early_seconds','提早加入秒數',calendar['join_early_seconds'],'number')+
                input_field('max_lateness_seconds','最晚加入秒數',calendar['max_lateness_seconds'],'number'))
            body += '<section><h2>'+h(calendar.get('name') or '新增 Calendar')+'</h2>'+form(session,'calendar',fields)+'</section>'
        safe = {key:getattr(settings,key) for key in ('display_name','timezone','calendar_poll_seconds','lookahead_hours',
            'max_duration_seconds','join_timeout_seconds','live_model','summary_model')}
        body += '<section><details><summary>進階執行設定</summary><p>由部署設定管理；此處不顯示憑證。</p><pre>'+h(
            json.dumps(safe,ensure_ascii=False,indent=2))+'</pre></details></section>'
        body += ('<section><h2>資料與管理</h2><nav><a href="/glossary">人名與術語</a> '
            '<a href="/audit">操作紀錄</a> <a href="/diagnostics">進階診斷</a></nav></section>')
        return page('設定',body,session)

    async def schedule(request):
        session = authenticated(request)
        rows = await asyncio.to_thread(daemon.store.list_occurrences)
        series = await asyncio.to_thread(daemon.store.list_series)
        choices = [('', '獨立單場會議')]+[(row['id'],row['name']) for row in series]
        now = datetime.now(ZoneInfo(settings.timezone)).replace(second=0,microsecond=0)
        body = '<section><h2>使用 Teams 連結安排會議</h2><p>時間以 '+h(settings.timezone)+' 顯示。建立場次不代表已加入；加入與記錄需先取得同意。</p>'
        fields = (input_field('title','會議名稱')+input_field('join_url','Teams 連結',kind='url')+
            input_field('start_at','開始時間',now.strftime('%Y-%m-%dT%H:%M'),kind='datetime-local')+
            input_field('end_at','結束時間',(now+timedelta(hours=1)).strftime('%Y-%m-%dT%H:%M'),kind='datetime-local')+
            select_field('series_id','接續哪一組會議',choices)+checkbox('recording_authorized','已取得加入及錄音授權')+
            checkbox('speaking_authorized','已授權本場小白發聲')+checkbox('join_now','建立後立即加入'))
        body += form(session,'manual',fields,'建立場次')+'</section><section><h2>場次</h2><table><tr><th>會議</th><th>時間／連結</th><th>狀態</th><th>操作</th></tr>'
        for row in rows:
            controls = ''
            if row['state']=='pending':
                controls += control(session,'join',row['id'],'加入')
            if row['state'] in {'pending','needs_review'}:
                controls += control(session,'skip',row['id'],'略過')
                controls += form(session,'assign-series',hidden('id',row['id'])+
                    select_field('series_id','指定系列',choices[1:],row['series_id']),'分組')
            body += ('<tr><td>'+h(row['title'])+'<br><a href="/series/'+h(row['series_id'])+'">系列記憶</a></td><td>'+h(row.get('start_at'))+
                '<br><span class="small">'+h(row.get('link_status'))+'</span></td><td>'+h(row['state'])+'</td><td>'+controls+'</td></tr>')
        return page('排程與人工入會',body+'</table></section>',session,active='schedule')

    async def history(request):
        session = authenticated(request)
        runs = await asyncio.to_thread(daemon.store.list_runs)
        body = '<section><table><tr><th>會議</th><th>開始</th><th>Capture</th><th>摘要</th></tr>'
        for run in runs:
            body += ('<tr><td><a href="/history/'+h(run['session_id'])+'">'+h(run['occurrence']['title'])+'</a></td><td>'+h(run['started_at'])+
                '</td><td>'+h(run['state'])+' / '+h(run['end_reason'])+'</td><td>'+h((run['source'].get('summary_state') or {}).get('generation_mode'))+'</td></tr>')
        return page('會議歷史',body+'</table></section>',session,active='history')

    async def history_detail(request):
        session = authenticated(request)
        ident = request.path_params['session_id']
        run = await asyncio.to_thread(daemon.store.get_run,ident)
        snapshot = await asyncio.to_thread(daemon.store.read,ident)
        body = '<section><h2>'+h(run['occurrence']['title'])+'</h2><p>'+h(run['state'])+' / '+h(run['end_reason'])+' / '+h(run['error_code'])+'</p>'
        review = run.get('cleanup_review') or {}
        if review.get('required'):
            terminal = run['state'] in TERMINAL|{'interrupted'} and run.get('ended_at') is not None
            worker = review.get('worker_status')
            worker_label = {'gone':'已確認舊 worker 不在','alive':'舊 worker 仍存活','unknown':'無法確認舊 worker 已停止'}.get(
                worker,'無法確認舊 worker 已停止')
            body += '<section><h2>人工確認中斷後的清理</h2>'
            if terminal:
                body += '<p class="error">此紀錄仍是歷史中斷／清理不確定的失敗，不會改寫為正常停止。</p>'
            else:
                body += '<p class="error">場次尚未完成終態封存；目前不能提交清理審查。</p>'
            body += ('<p>'+h(worker_label)+'</p><p>請先由人員確認舊瀏覽器、容器及相關程序已停止，'
                '且助理已離開會議。此確認僅解除這筆紀錄的 capture 安全阻擋，不代表 provider STOP 回覆或逐字稿最終定稿；'
                '不會重新加入會議、恢復排程或啟用發聲。</p>')
            if terminal and worker=='gone':
                fields = hidden('id',ident)+hidden('stamp',review['stamp'])
                fields += checkbox('resources_stopped','我已親自確認舊瀏覽器、容器及相關程序均已停止')
                fields += checkbox('assistant_left','我已親自確認助理已離開會議')
                body += form(session,'review-capture-cleanup',fields,'確認上述兩項並解除此紀錄的阻擋')
            elif not terminal:
                body += '<p class="error">請等待場次封存後重新載入；舊 worker 不在並不等於來源已封存。</p>'
            else:
                body += '<p class="error">仍存活或無法確認的 worker 不允許提交清理確認；請先人工處理並確認已停止。</p>'
            body += '</section>'
        elif review.get('reviewed_at'):
            body += '<p>人工清理確認時間：'+h(review['reviewed_at'])+'；操作者：'+h(review.get('actor'))+'。原始中斷及來源品質維持不變。</p>'
        body += '<p>來源 completeness：'+h(snapshot['completeness'])+'</p><pre>'+h(json.dumps(snapshot['transcript_state'],ensure_ascii=False,indent=2))+'</pre>'
        response = run['status'].get('response_status')
        if isinstance(response,dict):
            visible = {key:response.get(key) for key in
                ('state','error_code','startup_phase','output_enabled','output_muted','progress')}
            body += '<h2>語音 B 已保存快照</h2><p>觀測時間：'+h(run['status'].get('response_snapshot_at'))+'</p><pre>'+h(
                json.dumps(visible,ensure_ascii=False,indent=2))+'</pre><p>本機送音或 drain 不代表遠端可聽。</p>'
        glossary = run['glossary_snapshot']
        body += '<p>詞庫快照版本：'+h(glossary['version'])+'；筆數：'+h(len(glossary['entries']))+'；省略：'+h(glossary['omitted_count'])+'</p>'
        body += '<a href="/series/'+h(run['occurrence']['series_id'])+'">系列與待辦</a></section>'
        summary = snapshot.get('summary')
        if summary:
            body += '<section><h2>衍生摘要</h2><p>模型：'+h(summary.get('model'))+'；來源品質不是 provider 最終定稿的替代。</p>'
            for section in ('重點','決策','待辦','未決問題'):
                body += '<h3>'+h(section)+'</h3><ul>'
                for item in summary[section]:
                    links = ' '.join('<a href="#source-'+h(ident)+'">'+h(ident)+'</a>' for ident in item['sources'])
                    body += '<li>'+h(item['text'])+' '+h(item.get('owner'))+' '+h(item.get('date'))+' '+links+'</li>'
                body += '</ul>'
            body += '</section>'
        body += '<section><h2>來源記錄</h2><p>原文及 provenance；不以姓名或詞庫覆寫。</p>'
        for source in snapshot['sources']:
            body += ('<article id="source-'+h(source['id'])+'"><h3>'+h(source['id'])+'</h3><p>'+h(source['source_state'])+
                ' / revision '+h(source.get('revision',source.get('source_revision')))+' / '+h(source['quality'])+'</p><pre>'+h(source['text'])+'</pre></article>')
        return page('來源與摘要',body+'</section>',session,active='history')

    async def series_page(request):
        session = authenticated(request)
        ident = request.path_params['series_id']
        series = await asyncio.to_thread(daemon.store.get_series,ident)
        tasks = await asyncio.to_thread(daemon.store.list_tasks,ident)
        body = '<section><h2>'+h(series['name'])+'</h2><p>新摘要沒有提及舊待辦，不代表完成。</p>'
        for task in tasks:
            body += ('<article><p>'+h(task['text'])+' / '+h(task['owner'])+' / '+h(task['date'])+'</p><p>'+h(task['status'])+'</p>'+
                form(session,'task',hidden('id',task['id'])+select_field('status','狀態',
                    [('open','未完成'),('completed','完成'),('deferred','延後')],task['status']))+'</article>')
        return page('系列記憶與待辦',body+'</section>',session,active='history')

    async def glossary_page(request):
        session = authenticated(request)
        rows = await asyncio.to_thread(daemon.store.list_glossary)
        body = '<section><p>僅 active 且適用系列的詞彙於入會凍結。initialItems 不是 ASR hotword API，也不推定 speaker。</p>'
        body += '<a href="/glossary/new">新增詞彙</a><table><tr><th>詞彙</th><th>類別／範圍</th><th>狀態／版本</th><th>衝突</th></tr>'
        for row in rows:
            body += ('<tr><td><a href="/glossary/'+h(row['id'])+'">'+h(row['canonical'])+'</a></td><td>'+h(row['kind'])+' / '+h(row['scope'])+
                '</td><td>'+h(row['status'])+' / '+h(row['revision'])+'</td><td>'+h(', '.join(row['conflicts']))+'</td></tr>')
        return page('人名與術語詞庫',body+'</table></section>',session)

    async def glossary_edit(request):
        session = authenticated(request)
        ident = request.path_params['entry_id']
        row = await asyncio.to_thread(daemon.store.get_glossary,ident) if ident!='new' else {
            'kind':'term','canonical':'','aliases':[],'pronunciation':'','definition':'','scope':'global','series_id':None,'status':'pending'}
        series = await asyncio.to_thread(daemon.store.list_series)
        fields = ''.join(hidden(key,row[key]) for key in ('id','revision') if key in row)
        fields += (input_field('canonical','正式詞彙／人名',row['canonical'])+
            select_field('kind','類別',[('person','人名'),('term','術語'),('abbreviation','縮寫')],row['kind']))
        fields += '<label>別名（每行一個；同音不同人不可合併）<textarea name="aliases">'+h('\n'.join(row['aliases']))+'</textarea></label>'
        fields += (input_field('pronunciation','發音提示',row['pronunciation'])+input_field('definition','定義（單行）',row['definition'])+
            select_field('scope','範圍',[('global','全域'),('series','指定系列')],row['scope'])+
            select_field('series_id','系列',[('', '不指定')]+[(item['id'],item['name']) for item in series],row['series_id'] or '')+
            select_field('status','審核狀態',[('pending','待核准'),('active','已核准使用'),('disabled','停用')],row['status']))
        return page('維護詞庫','<section>'+form(session,'glossary',fields)+'</section>',session)

    async def audit_page(request):
        session = authenticated(request)
        rows = await asyncio.to_thread(daemon.store.audit)
        body = '<section><table><tr><th>時間</th><th>操作者</th><th>動作</th><th>目標 ID</th></tr>'
        for row in rows:
            body += '<tr>'+''.join('<td>'+h(row[key])+'</td>' for key in ('created_at','actor','action','target'))+'</tr>'
        return page('操作稽核',body+'</table></section>',session)

    async def action(request):
        _,values = await submitted(request)
        name = request.path_params['action']
        target = values.get('id')
        destination = '/'
        result = None
        if name in {'stop','output'} and 'acceptance_request' in values:
            run=await asyncio.to_thread(daemon.store.get_run,target)
            policy=run.get('acceptance_policy')
            if not policy or values['acceptance_request']!=policy['request_sha256']:
                raise AdminError('teams_acceptance_binding_rejected')
        if name=='scheduler':
            if values.get('paused') not in {'true','false'}:
                raise AdminError('invalid_scheduler_policy')
            if values['paused']=='false' and daemon.status()['capture_interlock']:
                raise AdminError('capture_cleanup_review_required')
            await asyncio.to_thread(daemon.store.update_settings,{'scheduler_paused':values['paused']=='true'})
        elif name=='poll':
            await daemon.poll_calendar()
        elif name=='calendar':
            fields = {key:values[key] for key in ('id','account_id','calendar_id','name') if key in values}
            fields.update(enabled='enabled' in values,recording_authorized='recording_authorized' in values,
                speaking_authorized='speaking_authorized' in values,join_early_seconds=integer(values,'join_early_seconds',60),
                max_lateness_seconds=integer(values,'max_lateness_seconds',300))
            if 'id' in fields:
                fields['revision'] = integer(values,'revision')
            await asyncio.to_thread(daemon.store.save_calendar,fields)
            destination = '/settings'
        elif name=='manual':
            fields = {key:values.get(key,'') for key in ('title','join_url','start_at','end_at')}
            fields['start_at'] = _local_meeting_time(fields['start_at'],settings.timezone)
            fields['end_at'] = _local_meeting_time(fields['end_at'],settings.timezone)
            fields.update(series_id=values.get('series_id') or None,recording_authorized='recording_authorized' in values,
                speaking_authorized='speaking_authorized' in values)
            row = await asyncio.to_thread(daemon.store.create_manual_occurrence,fields)
            if 'join_now' in values:
                await daemon.join(row['id'])
            destination = '/?meeting='+quote(row['id'],safe='')
        elif name=='join':
            acceptance=None
            if 'acceptance_request' in values:
                from .teams_acceptance import validate_policy, VERSION
                try:
                    if values.get('acceptance_stop_policy')!='owner_or_meeting_end' or 'acceptance_seconds' in values:
                        raise ValueError('teams_acceptance_policy_rejected')
                    acceptance=validate_policy({'version':VERSION,'request_sha256':values['acceptance_request'],
                        'occurrence_revision':integer(values,'acceptance_revision'),
                        'maximum_seconds':None})
                except ValueError:
                    raise AdminError('teams_acceptance_policy_rejected') from None
            result=await daemon.join(target,**({'acceptance':acceptance} if acceptance is not None else {}))
        elif name=='skip':
            await asyncio.to_thread(daemon.store.skip_occurrence,target)
            destination = '/schedule'
        elif name=='assign-series':
            await asyncio.to_thread(daemon.store.assign_series,target,values.get('series_id'))
            destination = '/schedule'
        elif name=='stop':
            await daemon.stop(target)
        elif name=='review-capture-cleanup':
            await daemon.review_capture_cleanup(target,values.get('stamp'),
                resources_stopped=values.get('resources_stopped')=='on',
                assistant_left=values.get('assistant_left')=='on',actor='admin')
            destination = '/history/'+quote(target or '',safe='')
        elif name=='output':
            if values.get('enabled') not in {'true','false'}:
                raise AdminError('invalid_output_policy')
            await daemon.set_output(target,values['enabled']=='true')
        elif name=='retry-summary':
            await daemon.retry_summary(target)
        elif name=='task':
            await asyncio.to_thread(daemon.store.update_task,target,values.get('status'))
            destination = '/history'
        elif name=='glossary':
            fields = {key:values.get(key,'') for key in ('kind','canonical','pronunciation','definition','scope','status')}
            fields.update(aliases=[value.strip() for value in values.get('aliases','').splitlines() if value.strip()],
                series_id=values.get('series_id') or None)
            if fields['scope']=='global':
                fields['series_id'] = None
            if target:
                fields.update(id=target,revision=integer(values,'revision'))
            await asyncio.to_thread(daemon.store.save_glossary,fields)
            destination = '/glossary'
        else:
            raise AdminError('unknown_admin_action')
        if 'application/json' in request.headers.get('accept',''):
            return JSONResponse({'ok':True,'destination':destination,**({'result':result} if result is not None else {})})
        return RedirectResponse(destination,status_code=303)

    def redirect_uri():
        base = settings.public_base_url.rstrip('/') if settings.public_base_url else 'http://127.0.0.1:'+str(settings.port)
        return base+'/google/callback'

    async def google_connect(request):
        session,_ = await submitted(request)
        state = secrets.token_urlsafe(32)
        uri = redirect_uri()
        url = daemon.google_authorization_url(uri,state)
        session['oauth'] = {'state':state,'redirect_uri':uri,'expires_at':time.time()+300}
        return RedirectResponse(url,status_code=303)

    async def google_callback(request):
        session = authenticated(request)
        pending = session.get('oauth')
        session['oauth'] = None
        states,codes = request.query_params.getlist('state'),request.query_params.getlist('code')
        if (not pending or pending['expires_at']<=time.time() or len(states)!=1 or len(codes)!=1
                or not hmac.compare_digest(states[0],pending['state']) or request.query_params.get('error')):
            raise AdminError('google_oauth_state_rejected')
        await daemon.google_exchange_code(codes[0],pending['redirect_uri'])
        await asyncio.to_thread(daemon.store.audit_control,'admin','google_authorized','google')
        return RedirectResponse('/settings',status_code=303)

    async def api_status(request):
        authenticated(request)
        return JSONResponse(daemon.status())

    async def api_calendar(request):
        authenticated(request)
        data = await asyncio.to_thread(daemon.store.calendar_view,
            request.query_params.get('start'),request.query_params.get('end'),settings.timezone)
        status = daemon.status()
        policy = await asyncio.to_thread(daemon.store.settings)
        now = datetime.now(ZoneInfo(settings.timezone))
        return JSONResponse({**data,'timezone':settings.timezone,'today':now.date().isoformat(),
            'now':now.isoformat(),'active_session_id':status.get('active_session_id'),
            'scheduler_paused':policy['scheduler_paused'],'capture_interlock':status['capture_interlock'],
            'google':{'authorized':bool(status['google'].get('authorized')),
                'error_code':status['google'].get('error_code')},'last_error':status.get('last_error')})

    async def api_meeting(request):
        authenticated(request)
        if request.query_params.get('view')=='acceptance':
            from .teams_acceptance import meeting_view
            view=await asyncio.to_thread(meeting_view,daemon.store,request.path_params['occurrence_id'])
            allowed=sorted(set(settings.allowed_egress_hosts))
            view['egress_policy_sha256']=hashlib.sha256(json.dumps(allowed,separators=(',',':')).encode()).hexdigest()
            view['egress_allows_target_host']=view['join_host'] in allowed
            status=daemon.status()
            response=status.get('response') or {}
            view['response_ready']=bool(view.get('session_id') and view['session_id']==status.get('active_session_id')
                and response.get('state') in {'sleeping','listening','thinking','answering'})
            return JSONResponse(view)
        data = await asyncio.to_thread(daemon.store.meeting_view,
            request.path_params['occurrence_id'],settings.timezone)
        if data.get('session_id'):
            def acceptance_status():
                from .teams_acceptance import receipt
                with daemon.store._locked() as db:
                    row=db.execute('SELECT status_json FROM session_runtime WHERE meeting_id=?',(data['session_id'],)).fetchone()
                    return receipt(db,data['session_id'],json.loads(row[0]) if row else {})
            data['acceptance']=await asyncio.to_thread(acceptance_status)
        status = daemon.status()
        active = bool(data['session_id'] and data['session_id']==status.get('active_session_id'))
        controls = data['controls']
        controls['stop'] = controls['stop'] and active
        controls['output'] = controls['output'] and active
        controls['join'] = controls['join'] and bool(status.get('started')) and not (
            status.get('active_session_id') or status.get('capture_interlock') or status.get('closing'))
        if active and isinstance(status.get('response'),dict):
            data['response'] = {key:status['response'].get(key) for key in
                ('state','output_enabled','output_muted','error_code','question_activity')}
        return JSONResponse(data)

    async def asset(request):
        filename = request.path_params['filename']
        if filename not in {'calendar.css','calendar.js'}:
            return PlainTextResponse('not_found',status_code=404)
        path = Path(__file__).with_name('static') / filename
        content = await asyncio.to_thread(path.read_bytes)
        return Response(content,media_type='text/css' if filename.endswith('.css') else 'application/javascript')

    async def health(request):
        return JSONResponse({'status':'ok' if daemon.status()['started'] else 'starting'})

    async def fixed_error(request,error):
        code = getattr(error,'code','admin_request_failed')
        if not isinstance(code,str) or not re.fullmatch('[a-z0-9_]{1,80}',code):
            code = 'admin_request_failed'
        json_request = request.url.path.startswith('/api/') or 'application/json' in request.headers.get('accept','')
        if code=='admin_login_required':
            if json_request:
                return JSONResponse({'error':code},status_code=401)
            return RedirectResponse('/login',status_code=303)
        status = 403 if code in {'admin_csrf_rejected','admin_origin_rejected','google_oauth_state_rejected'} else \
            409 if code=='revision_conflict' else 429 if code=='login_rate_limited' else 413 if code=='request_too_large' else 422
        if json_request:
            return JSONResponse({'error':code},status_code=404 if code=='record_not_found' else status)
        messages = {'admin_login_failed':'密碼不正確，請重新登入。',
            'admin_csrf_rejected':'頁面已過期，請重新載入後再操作。',
            'admin_origin_rejected':'無法確認操作來源，請從管理頁重新操作。',
            'revision_conflict':'資料已被更新，請重新載入後再修改。',
            'capture_cleanup_review_required':'上次離會狀態尚未確認，請先完成清理確認。',
            'record_not_found':'找不到這筆會議或資料。'}
        response = page('操作未完成','<p class="error">'+h(messages.get(code,'操作未完成，請確認目前狀態後再試。'))+
            '</p><details><summary>技術詳情</summary><code>'+h(code)+'</code></details><a href="/">返回行事曆</a>',request.state.admin_session)
        response.status_code = status
        return response

    @asynccontextmanager
    async def lifespan(app):
        from .teams_local_control import control_lifespan
        await daemon.start()
        try:
            async with control_lifespan(daemon,settings,local_teams_control):
                yield
        finally:
            await daemon.close()

    routes = [Route('/login',login,methods=['GET','POST']),Route('/logout',logout,methods=['POST']),
        Route('/',dashboard),Route('/settings',settings_page),Route('/schedule',schedule),Route('/diagnostics',diagnostics),
        Route('/history',history),Route('/history/{session_id}',history_detail),Route('/series/{series_id}',series_page),
        Route('/glossary',glossary_page),Route('/glossary/{entry_id}',glossary_edit),Route('/audit',audit_page),
        Route('/actions/{action}',action,methods=['POST']),Route('/google/connect',google_connect,methods=['POST']),
        Route('/google/callback',google_callback),Route('/api/status',api_status),
        Route('/api/calendar',api_calendar),Route('/api/meetings/{occurrence_id}',api_meeting),
        Route('/assets/{filename}',asset),Route('/healthz',health)]
    app = Starlette(routes=routes,lifespan=lifespan,exception_handlers={AdminError:fixed_error,
        AssistantStoreError:fixed_error,CalendarError:fixed_error,MeetingStoreError:fixed_error,RxContractError:fixed_error})
    app.add_middleware(AdminGuard,sessions=sessions,settings=settings)
    app.state.daemon,app.state.sessions = daemon,sessions
    return app
