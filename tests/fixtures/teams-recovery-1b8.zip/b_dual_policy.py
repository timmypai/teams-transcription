"""Explicit production dual-channel sender guard; RX-only policy is untouched.

Opt-in wiring (no A API is assumed):
    policy = OwnedSenderDualPolicy(frame, meeting_id)
    sink = BrowserTXSink(frame, meeting_id=meeting_id,
                         dual_channel_policy=policy.authorize)
    await sink.bind()
    # The dual-mode RX callback must await policy.check() before every PCM packet.
    # False is a capability failure: stop the session/output; never forward it.

The runtime owns window.__bMeetingId and must update it before meeting changes.
The callback alone is insufficient: the host must wire check into its RX path
and accept packets only from this bound frame/meeting. This class guards TX
capability; the host owns RX source routing.
This guard has no join/device/network behavior. It never acquires a microphone.
"""
import asyncio
import uuid


DUAL_CHECK_JS = r"""({policyId,meetingId,expected,authorize,initialized}) => {
  const muteOwned=state=>{if(state) state.revoke('dual_policy_rejected');};
  window.__bDualPolicies ||= new Map();
  let policy=window.__bDualPolicies.get(policyId);
  if(!policy) {
    if(initialized) return false;
    if(window.__bMeetingId!==meetingId || !window.__meeting?.peers) return false;
    policy={document,capture:window.__meeting,href:location.href,meetingId,
      binding:null,trackId:null,faulted:false};
    window.__bDualPolicies.set(policyId,policy);
  }
  const existing=policy.binding && window.__bTXOwnedStates?.get(policy.binding.owner);
  const fail=(muteForeign=false)=>{
    policy.faulted=true; muteOwned(existing);
    if(muteForeign) for(const pc of policy.capture.peers) for(const sender of pc.getSenders()) {
      if(sender.track && ['audio','video'].includes(sender.track.kind)) sender.track.enabled=false;
    }
    return false;
  };
  if(policy.faulted) return fail();
  // A reused frame/document cannot carry its old TX exception into a new meeting.
  if(policy.document!==document || policy.href!==location.href ||
     window.__bMeetingId!==meetingId || window.__meeting!==policy.capture) return fail();
  const current=b=>b && b.document===document && b.href===location.href &&
    b.meetingId===meetingId && b.capture===policy.capture &&
    policy.capture.peers[b.peerIndex]===b.pc && b.pc.connectionState!=='closed' &&
    b.pc.getSenders().includes(b.sender) && (b.original!==null ||
      (b.pc.getTransceivers().includes(b.transceiver) && b.transceiver.sender===b.sender));
  if(policy.binding && !current(policy.binding)) return fail();
  let binding=policy.binding, trackId=policy.trackId;
  if(authorize) {
    binding=window.__bTXBindings?.get(expected?.owner);
    if(!current(binding) || (policy.binding && policy.binding!==binding) ||
       expected.meeting_id!==meetingId || expected.document_id!==binding.documentId ||
       expected.peer_id!==binding.peerId || expected.sender_id!==binding.senderId)
      return fail();
    trackId=expected.track_id;
  }
  const owned=binding && window.__bTXOwnedStates?.get(binding.owner);
  const ownedIntact=owned && owned.installed && !owned.disposed && owned.binding===binding &&
    window.__bTX===owned && owned.pc===binding.pc && owned.sender===binding.sender &&
    owned.sender.track===owned.track && owned.track.kind==='audio' &&
    owned.track.readyState==='live' &&
    owned.relay.connectionState==='connected' && owned.control?.readyState==='open' &&
    owned.relay.getReceivers().includes(owned.receiver) &&
    owned.receiver?.track===owned.inputTrack &&
    owned.decoder?.receiver===owned.receiver && owned.decoder.inputTrack===owned.inputTrack &&
    owned.decoder.track===owned.track && owned.decoder.valid() &&
    (binding.original!==null || (binding.transceiver.stopped===false &&
      binding.transceiver.receiver?.track?.kind==='audio' &&
      ['sendonly','sendrecv'].includes(binding.transceiver.currentDirection)));
  const ownedValid=ownedIntact && owned.track.id===trackId;
  // stop() revokes output immediately but may await replaceTrack(original).
  // Both sides of that restore must keep RX alive while every sender is muted.
  const normalStopping=owned && owned.stopping===true && owned.disposed &&
    owned.binding===binding && window.__bTX===owned &&
    owned.pc===binding.pc && owned.sender===binding.sender && owned.muted &&
    !owned.track?.enabled && !owned.original?.enabled &&
    (owned.sender.track===owned.track || owned.sender.track===owned.original);
  if(authorize && !ownedValid) {muteOwned(owned);return fail(true);}
  // Identity loss faults even a muted replacement, before the periodic guard.
  // A new, muted relay may await authorization after a normal restore.
  if(owned && !normalStopping && (owned.disposed || (owned.installed && !ownedIntact))) {
    muteOwned(owned);return fail(true);
  }
  // Only this exact owned native sender/track may be enabled. Check ALL peers and
  // both audio/video; unrelated microphones/cameras stay disabled.
  let foreign=false;
  for(const pc of policy.capture.peers) for(const sender of pc.getSenders()) {
    const track=sender.track;
    if(track && ['audio','video'].includes(track.kind) && track.enabled &&
       !(ownedValid && !owned.muted && pc===binding.pc && sender===binding.sender && track===owned.track))
      foreign=true;
  }
  if(foreign) {
    // Authorize may be the first encounter with a lease; revoke that lease too.
    muteOwned(owned);
    return fail(true);
  }
  if(authorize) {policy.binding=binding;policy.trackId=trackId;}
  return true;
}"""


class OwnedSenderDualPolicy:
    """Inert until called; permits one bound receiver's no-PLC rendered track.

    authorize(binding) is BrowserTXSink's callback. check() is the production RX
    every-packet guard. A failure latches; create a new policy/sink after a meeting
    lifecycle change rather than silently rebinding this capability.
    """
    _FIELDS = ('meeting_id','document_id','peer_id','sender_id','owner','track_id')

    def __init__(self, frame, meeting_id, *, timeout=2):
        if not isinstance(meeting_id,str) or not meeting_id:
            raise ValueError('An explicit meeting identity is required')
        if not isinstance(timeout,(int,float)) or not 0 < timeout <= 5:
            raise ValueError('A bounded dual-policy timeout is required')
        self.frame, self.meeting_id, self.timeout = frame, meeting_id, timeout
        self.policy_id = uuid.uuid4().hex
        self.faulted = False
        self._initialized = False
        self._lock = asyncio.Lock()

    async def _evaluate(self, expected=None):
        async with self._lock:
            try:
                result=await asyncio.wait_for(self.frame.evaluate(DUAL_CHECK_JS,
                    {'policyId':self.policy_id,'meetingId':self.meeting_id,
                     'expected':expected,'authorize':expected is not None,
                     'initialized':self._initialized}),self.timeout)
            except Exception:
                self.faulted=True
                return False
            self._initialized |= result is True
            self.faulted |= result is not True
            return result is True and not self.faulted

    async def authorize(self,binding):
        if (not isinstance(binding,dict) or
                any(not isinstance(binding.get(key),str) or not binding[key] for key in self._FIELDS) or
                binding['meeting_id']!=self.meeting_id):
            self.faulted=True
            # Still perform the check to revoke a known existing lease.
            await self._evaluate({})
            return False
        return await self._evaluate({key:binding[key] for key in self._FIELDS})

    async def check(self):
        return await self._evaluate()
