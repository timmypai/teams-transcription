"""Bounded failure metadata; never persist exception text or browser content."""
import math
import traceback

PHASES = {"prepare", "prepared", "owner_wait", "live_start", "browser_open", "meeting_join", "rx_start",
          "rx_scan", "rx_capture", "rx_drain", "live_drain", "summary", "cleanup"}
FILES = {"browser.py", "live.py", "worker.py", "meeting_store.py", "storage.py"}
EXCEPTION_TYPES = {"TimeoutError", "Error", "TargetClosedError", "RuntimeError",
                   "ValueError", "OSError", "QueueFull", "InterruptedError", "RxContractError"}

LIVE_CODES = {'live_session_expired', 'live_session_closed', 'live_transport_reset',
              'live_media_not_ready',
              'live_realtime_error', 'live_app_server_exit', 'live_notification_invalid',
              'live_source_failed', 'live_receiver_failed', 'live_error_unknown'}
LIVE_CHANNELS = {'rpc', 'datachannel', 'receiver', 'source', 'unknown'}
LIVE_STAGES = {'rpc_start', 'account_read', 'thread_start', 'ice_gather', 'realtime_start',
               'sdp_answer', 'sdp_apply', 'media_connect', 'connected', 'closing', 'unknown'}
LIVE_TYPES = {'session.closed', 'error', 'thread/realtime/closed', 'thread/realtime/error',
              'client/exit', 'notification_invalid', 'receiver_failed', 'source_failed', 'unknown'}
LIVE_REASONS = {'expired', 'requested', 'client_request', 'transport_closed', 'error', 'stopped', 'unknown'}

JOIN_PHASES = {'context_setup', 'page_create', 'page_setup', 'goto', 'page_ready',
               'starting', 'body_read', 'admission_check', 'browser_choice', 'audio_choice', 'preview_navigation',
               'name_fill', 'mute_controls', 'join_control_scan', 'join_dispatch',
               'post_join_wait', 'lobby_wait', 'joined', 'unknown'}
JOIN_PAGE_STATES = {'unknown', 'unrecognized', 'prejoin_controls', 'connecting', 'lobby',
                    'joined', 'login_required', 'connect_failed', 'ended'}
JOIN_ACTIONS = {'browser_continue', 'audio_continue', 'computer_audio', 'name', 'mute', 'join'}
JOIN_CONTROLS = JOIN_ACTIONS | {'leave'}
JOIN_RESULTS = {'not_attempted', 'inspecting', 'not_visible', 'dispatching', 'completed', 'error'}
JOIN_OUTCOMES = {'in_progress', 'joined', 'timeout', 'stopped', 'cancelled', 'error', 'unknown'}
JOIN_EXCEPTION_TYPES = EXCEPTION_TYPES | {'Exception', 'CancelledError', 'ResponseUIContextError', 'none'}

# B startup receipts contain fixed labels only, never exception text or paths.
RESPONSE_START_PHASES = {'not_started', 'guard_construct', 'guard_prepare',
    'sender_select', 'policy_construct', 'sink_construct', 'sink_bind',
    'policy_check', 'policy_bind', 'native_construct', 'native_start',
    'cli_preflight', 'cli_version_spawn', 'cli_version_wait', 'cli_version_check',
    'rpc_initialize', 'account_read', 'thread_start', 'peer_bind', 'ice_offer',
    'realtime_start_ack', 'sdp_answer', 'sdp_authorize', 'sdp_apply',
    'media_connected', 'native_output_attach', 'context_bind', 'ready', 'native_stop', 'policy_release'}
RESPONSE_EXCEPTION_TYPES = JOIN_EXCEPTION_TYPES | {'FileNotFoundError',
    'PermissionError', 'ConnectionError', 'KeyError', 'AttributeError',
    'TypeError', 'UnicodeDecodeError'}
RESPONSE_OUTPUT_STEPS = {'output_scope', 'relay_scope', 'source_offer',
    'target_answer', 'source_answer', 'target_ready', 'source_check',
    'sender_install', 'initial_mute'}

RESPONSE_RUNTIME_PHASES = {'audio_callback', 'datachannel', 'document', 'rx_push',
    'notification', 'rpc', 'speech_start', 'speech_completion', 'continuation', 'unknown'}
RESPONSE_RUNTIME_CODES = {'response_failed', 'response_output_backpressure',
    'response_decoder_failed', 'response_output_delivery_failed',
    'response_document_invalidated', 'response_datachannel_error',
    'response_rpc_error', 'response_transport_closed', 'response_app_server_exit',
    'response_input_failed', 'response_notification_failed', 'response_pcm_invalid',
    'response_pcm_delivery_failed', 'response_speech_start_failed',
    'response_speech_completion_failed', 'response_continuation_failed',
    'response_continuation_overflow', 'response_turn_identity_capacity'}


def response_start_failure(exc, phase, *, output_step=None):
    kind = type(exc).__name__ if exc is not None else 'none'
    value = {'phase': phase, 'exception_type': kind}
    if output_step is not None:value['output_step'] = output_step
    return response_start_receipt(value)


def response_start_receipt(value):
    result = {'phase': value.get('phase') if isinstance(value.get('phase'), str)
                and value['phase'] in RESPONSE_START_PHASES else 'unknown',
            'exception_type': value.get('exception_type')
                if isinstance(value.get('exception_type'), str)
                and value['exception_type'] in RESPONSE_EXCEPTION_TYPES else 'Exception'}
    if result['phase'] == 'native_output_attach' and 'output_step' in value:
        result['output_step'] = value['output_step'] if isinstance(value['output_step'], str) \
            and value['output_step'] in RESPONSE_OUTPUT_STEPS else 'unknown'
    return result


def response_runtime_failure_receipt(value):
    if not isinstance(value, dict):
        return None
    elapsed = value.get('elapsed_ms')
    return {'code': value.get('code') if isinstance(value.get('code'), str)
                and value['code'] in RESPONSE_RUNTIME_CODES else 'response_failed',
            'phase': value.get('phase') if isinstance(value.get('phase'), str)
                and value['phase'] in RESPONSE_RUNTIME_PHASES else 'unknown',
            'exception_type': value.get('exception_type')
                if isinstance(value.get('exception_type'), str)
                and value['exception_type'] in RESPONSE_EXCEPTION_TYPES else 'Exception',
            'elapsed_ms': min(elapsed, 86400000)
                if type(elapsed) is int and elapsed >= 0 else None}


def response_progress_diagnostic(value):
    """Read-only B progress: fixed labels/counts, never transcript or media."""
    if not isinstance(value, dict):
        return None
    def section(parent, name):
        item = parent.get(name)
        return item if isinstance(item, dict) else {}
    def count(item, maximum=2147483647):
        return min(item, maximum) if type(item) is int and item >= 0 else 0
    def measurement(item):
        if type(item) is int and item >= 0:
            return min(item, 2147483647)
        if type(item) is float and math.isfinite(item) and item >= 0:
            return min(item, 2147483647)
        return None
    def label(item, allowed):
        return item if isinstance(item, str) and item in allowed else 'unknown'
    receipts = section(value, 'question_receipts')
    counts = section(receipts, 'counts')
    pending = section(value, 'input_pending')
    fanout = section(value, 'fanout')
    transcripts = section(value, 'transcript_notifications')
    tx = section(value, 'tx')
    speech = section(value, 'speech_completion')
    drain = section(speech, 'drain_result')
    context = section(value, 'context')
    context_error = value.get('context_failure_code')
    events = receipts.get('events')
    events = events[-64:] if isinstance(events, list) else []
    reasons = {'invalid_question', 'state_not_listening', 'scope_changed',
        'runtime_failed', 'stopped', 'duplicate_request'}
    last_rejection = next((label(event.get('reason'), reasons)
        for event in reversed(events) if isinstance(event, dict) and event.get('reason') is not None), None)
    error = speech.get('error_code')
    deliveries = value.get('tool_deliveries')
    deliveries = deliveries[-16:] if isinstance(deliveries, list) else []
    safe_deliveries = []
    for item in deliveries:
        if not isinstance(item, dict):
            continue
        indexes = item.get('selected_record_indexes')
        indexes = indexes if isinstance(indexes, list) else []
        version = item.get('source_version')
        safe_deliveries.append({
            'question_number':count(item.get('question_number')),
            'phase':label(item.get('phase'), {'preparing','sending','delivered','cancelled','failed'}),
            'started_elapsed_ms':count(item.get('started_elapsed_ms'), 86400000),
            'source_version':count(version) if type(version) is int and version >= 0 else None,
            'available':item.get('available') is True,
            'selected_ref_count':count(item.get('selected_ref_count')),
            'selected_record_indexes':[min(index, 2147483647) for index in indexes[:64]
                if type(index) is int and index > 0],
            'selected_indexes_truncated':item.get('selected_indexes_truncated') is True or len(indexes)>64,
            'omitted_for_budget':item.get('omitted_for_budget') is True,
            'payload_bytes':count(item.get('payload_bytes')),
            'sent_bytes':count(item.get('sent_bytes')),
            'marker_returned':item.get('marker_returned') is True,
            'model_consumption_verified':False})
    return {'schema_version': 4,
        'state': label(value.get('state'), {'starting', 'sleeping', 'listening', 'greeting',
            'thinking', 'answering', 'failed', 'stopping', 'stopped', 'stop_unknown', 'unavailable'}),
        'rx': {'accepted_packets': count(value.get('rx_accepted_packets')),
            'peer_push_packets': count(value.get('rx_peer_push_packets')),
            'dropped_packets': count(value.get('rx_dropped'))},
        'fanout': {key: count(fanout.get(key)) for key in
            ('clock_missing_packets', 'offered_packets', 'accepted_packets', 'rejected_packets', 'error_packets')},
        'transcripts': {key: count(transcripts.get(key)) for key in
            ('user_delta', 'user_done', 'assistant_delta', 'assistant_done')},
        'tx': {'available': tx.get('available') is True,
            'connected': tx.get('connected') is True,
            **{key: count(tx.get(key)) for key in ('packets', 'frames')},
            **{key: measurement(tx.get(key)) for key in ('duration', 'energy')}},
        'pending_input': {'characters': count(pending.get('characters')),
            'has_wake': pending.get('has_wake') is True,
            'has_question': pending.get('has_question') is True},
        'question_receipts': {**{key: count(counts.get(key)) for key in ('received', 'admitted', 'rejected')},
            'last_rejection': last_rejection},
        'tool_calls': count(value.get('tool_calls')),
        'tool_deliveries':safe_deliveries,
        'context': {'sent_bytes': count(context.get('sent_bytes')),
            'total_limit_bytes': None,
            'committed_records': count(context.get('committed_records')),
            'pending': context.get('pending') is True,
            'failure_code': None if context_error is None else label(context_error, {
                'context_same_version_conflict','context_version_rollback','context_failure'})},
        'speech': {'phase': label(speech.get('phase'), {'not_started', 'waiting_greeting_text',
                'waiting_done', 'waiting_activity', 'waiting_quiet', 'draining', 'closing', 'closed'}),
            'error_code': None if error is None else label(error, {'native_error', 'speech_task_timeout',
                'speech_task_failed', 'speech_cancelled', 'speech_timeout', 'speech_failed'}),
            'done_is_set': speech.get('done_is_set') is True,
            'output_active': speech.get('output_active') is True,
            'drained': False,
            'quiet': drain.get('quiet') is True,
            'truncated': drain.get('truncated') is True,
            'connected': speech.get('connected') is True,
            **{key: count(speech.get(key)) for key in ('frames', 'activity_frames')},
            **{key: measurement(speech.get(key)) for key in
                ('received_duration', 'received_energy', 'quiet_received_seconds')}}}


def sender_selection_diagnostic(value):
    """Fixed counters only; bound size even if a page supplies hostile values."""
    if not isinstance(value, dict):
        return None
    def count(v):
        return min(v, 65535) if type(v) is int and v >= 0 else 0
    def direction(v):
        return v if isinstance(v, str) and v in {'sendonly','sendrecv','recvonly','inactive','none','other'} else 'other'
    def audio_rows(peer):
        rows=peer.get('audio_transceivers')
        rows=rows if isinstance(rows,list) else []
        allowed={'peer_closed','transceiver_stopped','stopped_unknown','sender_missing',
            'sender_track_present','current_not_sending','sender_not_member','eligible'}
        return {'audio_transceivers_truncated':peer.get('audio_transceivers_truncated') is True or len(rows)>8,
            'audio_transceivers':[{'direction':direction(row.get('direction')),
                'currentDirection':direction(row.get('currentDirection')),
                'sender_member':row.get('sender_member') is True,
                'sender_track_null':row.get('sender_track_null') is True,
                'stopped':row.get('stopped') is True,
                'rejection_reason':row.get('rejection_reason')
                    if isinstance(row.get('rejection_reason'),str)
                    and row['rejection_reason'] in allowed else 'unknown'}
                for row in rows[:8] if isinstance(row,dict)]}
    def counters(v):
        return {key:count(v.get(key)) for key in ('sender_count', 'track_count',
            'audio_count', 'audio_live_count', 'audio_ended_count',
            'audio_enabled_count', 'audio_muted_count', 'eligible_count',
            'transceiver_count', 'receiver_audio_count', 'receiver_video_count',
            'receiver_absent_count', 'receiver_other_count', 'stopped_count',
            'stopped_unknown_count', 'null_sender_count', 'null_send_eligible_count',
            *(prefix+'_'+kind for prefix in ('direction','current','audio_direction','audio_current')
                for kind in ('sendonly','sendrecv','recvonly','inactive','none','other')))}
    frames = value.get('frames')
    frames = frames if isinstance(frames, list) else []
    result = {'schema_version':1, 'frame_count':count(value.get('frame_count')),
        'eligible_count':count(value.get('eligible_count')), 'frames':[],
        'enumeration_complete':value.get('enumeration_complete') is True,
        'frames_truncated':value.get('frames_truncated') is True or len(frames) > 8,
        'outcome':value.get('outcome') if isinstance(value.get('outcome'), str)
            and value['outcome'] in {'scanning','none','multiple','selected',
                'evaluation_failed','binding_failed'} else 'unknown'}
    for frame in frames[:8]:
        if not isinstance(frame, dict):
            continue
        peers = frame.get('peers')
        peers = peers if isinstance(peers, list) else []
        result['frames'].append({**counters(frame),
            'hook_available':frame.get('hook_available') is True,
            'peers_available':frame.get('peers_available') is True,
            'peer_count':count(frame.get('peer_count')),
            'peers_truncated':frame.get('peers_truncated') is True or len(peers) > 16,
            'peers':[{**counters(peer), 'peer_available':peer.get('peer_available') is True,
                'transceivers_available':peer.get('transceivers_available') is True,
                **audio_rows(peer),
                'closed':peer.get('closed') is True}
                for peer in peers[:16] if isinstance(peer, dict)]})
    return result


PREJOIN_UI_ROLES=('radio','button','link','textbox','heading','dialog')
PREJOIN_UI_NAMES=('computer_audio_radio','browser_continue_button','browser_continue_link',
    'join_button','guest_entry_button','guest_entry_link','sign_in_button','sign_in_link',
    'unsupported_message','lobby_message','ended_message','error_message','dismiss_button',
    'audio_fallback_button','app_open_button','auth_error_message','meeting_missing_message',
    'media_blocked_message','cookies_blocked_message','continue_without_av_button',
    'dont_use_audio_button','join_without_audio_button','device_preview_dialog_message','leave_button','mute_button')
PREJOIN_UI_CATEGORIES={'unknown','prejoin','browser_choice','guest_entry','login_prompt',
    'unsupported_browser','admission_lobby','meeting_ended','error_message','multiple_known_categories',
    'auth_error','meeting_unavailable','media_permission_or_device_message','cookies_message','app_choice','audio_fallback','meeting_controls_candidate'}


def prejoin_ui_diagnostic(value):
    """Only fixed enums/counters: never browser text, names, URLs or attributes."""
    if not isinstance(value,dict):
        return None
    def count(item):
        return min(item,65535) if type(item) is int and item>=0 else 0
    def millis(item):
        return min(item,900000) if type(item) is int and item>=0 else None
    roles=value.get('role_counts');roles=roles if isinstance(roles,dict) else {}
    names=value.get('safe_name_counts');names=names if isinstance(names,dict) else {}
    unknown=value.get('unknown_name_counts');unknown=unknown if isinstance(unknown,dict) else {}
    categories=value.get('category_candidates');categories=categories if isinstance(categories,list) else []
    scopes={'last_complete_observation','previous_complete_observation','before_context_invalidation','not_available','post_join_observation'}
    return {'schema_version':1,
        'category':value.get('category') if isinstance(value.get('category'),str)
            and value['category'] in PREJOIN_UI_CATEGORIES else 'unknown',
        'category_candidates':sorted({x for x in categories if isinstance(x,str)
            and x in PREJOIN_UI_CATEGORIES and x not in {'unknown','multiple_known_categories'}})[:16],
        'origin_kind':value.get('origin_kind') if isinstance(value.get('origin_kind'),str) and value.get('origin_kind') in
            {'teams','microsoft_identity','browser_error','other','unknown'} else 'unknown',
        'role_counts':{key:count(roles.get(key)) for key in PREJOIN_UI_ROLES},
        'safe_name_counts':{key:count(names.get(key)) for key in PREJOIN_UI_NAMES},
        'unknown_name_counts':{key:count(unknown.get(key)) for key in ('radio','button','link')},
        'text_lookup_supported':value.get('text_lookup_supported') is True,
        'sample_scope':value.get('sample_scope') if isinstance(value.get('sample_scope'),str) and value.get('sample_scope') in scopes else 'not_available',
        'sample_time_basis':'complete_scan_end',
        'sample_sequence':count(value.get('sample_sequence')),
        'observed_elapsed_ms':millis(value.get('observed_elapsed_ms')),
        'sample_age_ms':millis(value.get('sample_age_ms')),
        'observation_duration_ms':millis(value.get('observation_duration_ms')),
        'latest_attempt_error':value.get('latest_attempt_error') if isinstance(value.get('latest_attempt_error'),str) and value.get('latest_attempt_error') in
            {'none','playwright_error','timeout','target_closed'} else 'none'}


def post_join_ui_diagnostic(value):
    """Only a fresh complete post-Join sample may publish UI categories/counts."""
    value = value if isinstance(value, dict) else {}
    reasons = {'none', 'not_attempted', 'pending', 'stale', 'stopped', 'deadline', 'cancelled',
        'timeout', 'target_closed', 'context_changed', 'observation_failed', 'playwright_error'}
    reason = value.get('unavailable_reason')
    reason = reason if isinstance(reason, str) and reason in reasons else 'not_attempted'
    snapshot = prejoin_ui_diagnostic(value.get('snapshot'))
    available = (value.get('available') is True and reason == 'none' and snapshot is not None
        and snapshot['sample_scope'] == 'post_join_observation'
        and snapshot['sample_age_ms'] is not None and snapshot['sample_age_ms'] <= 1500)
    if reason == 'none' and not available:
        reason = 'stale'
    age = value.get('last_sample_age_ms')
    attempts = value.get('observation_attempts')
    return {'schema_version': 1, 'observation_scope': 'post_join_only',
        'available': available, 'unavailable_reason': reason, 'freshness_limit_ms': 1500,
        'last_sample_age_ms': min(age, 900000) if type(age) is int and age >= 0 else None,
        'observation_attempts': min(attempts, 65535) if type(attempts) is int and attempts >= 0 else 0,
        'snapshot': snapshot if available else None}


def computer_audio_wait_diagnostic(value):
    if not isinstance(value, dict):
        return None
    def enum(key, values, fallback):
        item=value.get(key)
        return item if isinstance(item,str) and item in values else fallback
    result={'stage':enum('stage',{'select','verify'},'select'),
        'wait_outcome':enum('wait_outcome',{'not_waited','waiting','became_visible','deadline','stopped','cancelled','error'},'error'),
        'classification':enum('classification',{'scanning','radio_absent','radio_hidden','visible','ambiguous','not_selected','checked','context_invalid','frame_snapshot_discarded'},'scanning'),
        'invalidation_reason':enum('invalidation_reason',{'unknown','none','page_closed','page_replaced','frame_detached','frame_removed','roster_changed'},'unknown'),
        'invalidation_stage':enum('invalidation_stage',{'none','primary_scan','auxiliary_scan','radio_readback','radio_dispatch','verify_return','join_visibility','join_dispatch','preview_scan','preview_dispatch','preview_return'},'none'),
        'auxiliary_error_kind':enum('auxiliary_error_kind',{'none','playwright_error','timeout','target_closed'},'none'),
        'auxiliary_exception_type':enum('auxiliary_exception_type',{'none','Error','TimeoutError','TargetClosedError'},'none'),
        'auxiliary_error_observation':enum('auxiliary_error_observation',{'none','all_radio_count','dialog_count',
            'known_browser_button_count','known_join_button_count','document_state'},'none'),
        'document_state':enum('document_state',{'loading','interactive','complete','unknown'},'unknown')}
    for key in ('poll_count','rescan_count','auxiliary_error_count','frame_count','exact_radio_count','visible_radio_count',
                'all_radio_count','dialog_count','known_browser_button_count','known_join_button_count'):
        item=value.get(key)
        result[key]=min(item,65535) if type(item) is int and item>=0 else 0
    result['browser_continue_completed']=value.get('browser_continue_completed') is True
    result['context_counts_checked']=value.get('context_counts_checked') is True
    result['observation_error']=value.get('observation_error') is True
    for key in ('page_closed','frame_checked','frame_detached','frame_member','invalidation_recorded','primary_scan_complete'):
        result[key]=value.get(key) is True
    count_keys=('all_radio_count','dialog_count','known_browser_button_count','known_join_button_count')
    prior_complete=(all(type(value.get(key)) is int and value[key]>=0 for key in count_keys)
        and isinstance(value.get('document_state'),str) and value.get('document_state') in {'loading','interactive','complete'})
    result['context_counts_scope']=('last_missing_scan' if result['context_counts_checked'] else
        'previous_complete_missing_scan' if prior_complete else 'not_checked')
    result['invalidation_scope']='last_recorded_invalidation' if result['invalidation_recorded'] else 'none'
    result['primary_counts_scope']='last_complete_primary_scan' if result['primary_scan_complete'] else 'incomplete_or_discarded'
    for key in ('primary_observed_elapsed_ms','primary_sample_age_ms','context_observed_elapsed_ms',
                'context_sample_age_ms','context_observation_duration_ms'):
        item=value.get(key)
        result[key]=min(item,900000) if type(item) is int and item>=0 else None
    result['ui_snapshot']=prejoin_ui_diagnostic(value.get('ui_snapshot'))
    return result


def teams_join_diagnostic(value):
    """Fixed enums/booleans only; independent of page/provider payload shape."""
    value = value if isinstance(value, dict) else {}
    def enum(item, allowed, fallback):
        return item if isinstance(item, str) and item in allowed else fallback
    result = {'schema_version': 1,
              'phase': enum(value.get('phase'), JOIN_PHASES, 'unknown'),
              'page_state': enum(value.get('page_state'), JOIN_PAGE_STATES, 'unknown'),
              'outcome': enum(value.get('outcome'), JOIN_OUTCOMES, 'unknown'),
              'exception_type': enum(value.get('exception_type'), JOIN_EXCEPTION_TYPES, 'none')}
    for key in ('context_ready', 'page_ready', 'goto_started', 'goto_completed',
                'body_observed', 'join_dispatch_started', 'join_dispatch_completed',
                'preview_navigation_dispatched','preview_navigation_completed'):
        result[key] = value.get(key) is True
    for field in ('controls_checked', 'controls_seen'):
        controls = value.get(field)
        controls = controls if isinstance(controls, dict) else {}
        result[field] = {key: controls.get(key) is True for key in sorted(JOIN_CONTROLS)}
    actions = value.get('actions')
    actions = actions if isinstance(actions, dict) else {}
    result['actions'] = {key: enum(actions.get(key), JOIN_RESULTS, 'not_attempted')
                         for key in sorted(JOIN_ACTIONS)}
    errors = value.get('errors')
    result['errors'] = [{'phase': enum(e.get('phase'), JOIN_PHASES, 'unknown'),
                         'action': enum(e.get('action'), JOIN_CONTROLS, 'unknown'),
                         'exception_type': enum(e.get('exception_type'), JOIN_EXCEPTION_TYPES, 'Exception')}
                        for e in errors[-8:] if isinstance(e, dict)] if isinstance(errors, list) else []
    result['computer_audio_wait']=computer_audio_wait_diagnostic(value.get('computer_audio_wait'))
    result['post_join_ui']=post_join_ui_diagnostic(value.get('post_join_ui'))
    return result


def live_failure(value):
    """Persist only fixed enums, independently of a provider's raw error text."""
    value = value if isinstance(value, dict) else {}
    fields = [('error_code', LIVE_CODES, 'live_error_unknown'),
              ('channel', LIVE_CHANNELS, 'unknown'), ('type', LIVE_TYPES, 'unknown'),
              ('reason', LIVE_REASONS, 'unknown'), ('stage', LIVE_STAGES, 'unknown')]
    return {key: value.get(key) if isinstance(value.get(key), str) and value[key] in allowed else fallback
            for key, allowed, fallback in fields}


def failure_diagnostic(exc, phase):
    kind = type(exc).__name__
    if kind not in EXCEPTION_TYPES:
        kind = "Exception"
    result = {"phase": phase if phase in PHASES else "unknown", "exception_type": kind,
              "error_code": "timeout" if isinstance(exc, TimeoutError) else "operation_failed"}
    for frame in reversed(traceback.extract_tb(exc.__traceback__)):
        name = frame.filename.rsplit("/", 1)[-1]
        if name in FILES:
            result["source"] = {"file": name, "line": frame.lineno}
            break
    return result
