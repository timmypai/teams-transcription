"""Fresh complete SQLite source readings for each meeting-bound question.

Host send receipts account for complete delivery, not model consumption.
Source locators remain authoritative on the host; readable projections never
turn application receipt fragments into provider-final utterances.
"""
from dataclasses import dataclass
import hashlib
import inspect
import json
import uuid

from .b_response import MeetingMinutesTool


class ContextFailure(ValueError):
    pass


def _json(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def _digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


@dataclass(frozen=True)
class ContextPlan:
    token: str
    session_id: str
    result: dict
    payload: str


def _records(snapshot):
    """Validate unique source slots before constructing citation references."""
    result, logical_ids, source_ids = {}, set(), set()
    for number, record in enumerate(snapshot['records'], 1):
        if (not isinstance(record, dict) or not isinstance(record.get('logical_id'), str)
                or not record['logical_id'] or not isinstance(record.get('source_id'), str)
                or not record['source_id'] or not isinstance(record.get('text'), str)
                or not isinstance(record.get('locator'), dict)):
            raise ContextFailure('invalid_context_record')
        if record['logical_id'] in logical_ids or record['source_id'] in source_ids:
            raise ContextFailure('ambiguous_context_source_identity')
        locator = record['locator']
        if (locator.get('source_id', record['source_id']) != record['source_id']
                or locator.get('record_index', number) != number):
            raise ContextFailure('invalid_context_source_locator')
        logical_ids.add(record['logical_id'])
        source_ids.add(record['source_id'])
        result[number] = {'record_index': number, 'text': record['text']}
    return result


class MeetingQuestionContext:
    def __init__(self, tool):
        if not isinstance(tool, MeetingMinutesTool):
            raise ContextFailure('invalid_context_configuration')
        self.tool = tool
        self.session_id = None
        self.sent_bytes = 0
        self._committed_records = 0
        self._version = None
        self._snapshot_sha256 = None
        self._pending = None
        self._preparing = None

    def bind_session(self, session_id):
        if not isinstance(session_id, str) or not session_id or len(session_id) > 256:
            raise ContextFailure('invalid_context_session')
        if session_id != self.session_id:
            self.session_id = session_id
            self.sent_bytes = 0
            self._committed_records, self._version, self._pending = 0, None, None
            self._snapshot_sha256 = None
            self._preparing = None

    def _scope(self, session_id):
        if not self.session_id or session_id != self.session_id:
            raise ContextFailure('context_session_changed')

    def invalidate(self, session_id):
        self._scope(session_id)
        self._pending = None
        self._preparing = None

    async def prepare(self, question, *, session_id, request_id=None):
        self._scope(session_id)
        if self._pending is not None or self._preparing is not None:
            raise ContextFailure('context_plan_pending')
        token = object()
        self._preparing = token
        try:
            return await self._prepare(question, session_id=session_id,
                prepare_token=token, request_id=request_id)
        finally:
            if self._preparing is token:
                self._preparing = None

    def _prepare_scope(self, session_id, token):
        self._scope(session_id)
        if self._preparing is not token:
            raise ContextFailure('context_prepare_invalidated')

    async def _prepare(self, question, *, session_id, prepare_token, request_id):
        if not isinstance(question, str) or not question:
            raise ContextFailure('invalid_context_question')
        if request_id is not None and (not isinstance(request_id, str) or not 1 <= len(request_id) <= 256):
            raise ContextFailure('invalid_context_request')
        request = {'kind': 'application_question', 'request_id': request_id,
            'question': question, 'provider_final': False}
        snapshot = self.tool.reader(self.tool.meeting_id)
        if inspect.isawaitable(snapshot): snapshot = await snapshot
        self._prepare_scope(session_id, prepare_token)
        if (not isinstance(snapshot, dict) or snapshot.get('meeting_id') != self.tool.meeting_id
                or not isinstance(snapshot.get('records'),list)
                or snapshot.get('version') is not None and (
                    type(snapshot['version']) is not int or snapshot['version'] < 0)):
            raise ContextFailure('invalid_context_snapshot')
        version = snapshot.get('version')
        if self._version is not None and (version is None or version < self._version):
            raise ContextFailure('context_version_rollback')
        digest = _digest(_json(snapshot['records']))
        if version is not None and version == self._version and digest != self._snapshot_sha256:
            raise ContextFailure('context_same_version_conflict')
        catalog = _records(snapshot)
        # Read the bound current source once. No local text-size policy may
        # remove authorized source rows before serialization.
        selected = await MeetingMinutesTool(self.tool.meeting_id, lambda _: snapshot).dispatch(
            self.tool.name, {'query': question})
        self._prepare_scope(session_id, prepare_token)
        result = self._assemble(selected, catalog)
        result['snapshot_sha256'] = digest
        payload = self._wire_payload(result, request)
        required = len(payload.encode('utf-8')) + len('RESULT_COMPLETE')
        plan = ContextPlan(uuid.uuid4().hex, session_id, result, payload)
        self._version = version
        self._snapshot_sha256 = digest
        self._pending = {'plan':plan,'required':required,'returned':0,
            'records':len(catalog)}
        return plan

    def _assemble(self, selected, catalog):
        refs = [{'record_index': index, 'char_start': 0, 'char_end': len(row['text'])}
            for index, row in catalog.items()]
        result = {key: value for key, value in selected.items() if key != 'context'}
        result.update(selected_context_refs=refs, context_mode='full_snapshot',
            context_scope='meeting_and_live_thread', omitted_for_budget=False,
            model_consumption_verified=False)
        projections = self._receipt_readings(result, catalog)
        projected = {position['record_index'] for row in projections
            for position in row['record_ranges']}
        starts = {row['record_ranges'][0]['record_index']: row for row in projections}
        locators = {row['record_index']: row for row in result['source_locators']}
        readings = []
        for index, row in catalog.items():
            if index in starts:
                readings.append(starts[index])
            elif index not in projected:
                locator = locators[index]
                reading = {**row, 'provenance': locator.get('provenance'),
                    'quality': locator.get('quality'), 'provider_final': locator.get('provider_final')}
                reading.update({key:locator[key] for key in ('source_id','revision','source_revision') if key in locator})
                if 'historical_context' in locator:
                    reading['historical_context'] = locator['historical_context']
                readings.append(reading)
        result['selected_source_reading'] = readings
        return result

    @staticmethod
    def _receipt_readings(result, catalog):
        """Readable, source-mapped projection, not a new utterance or final."""
        locators = {row['record_index']:row for row in result['source_locators']}
        readings, group = [], []
        def flush():
            if len(group) > 1:
                readings.append({'construction':'ordered_receipt_projection',
                    'capture_id':group[0][1]['capture_id'], 'source_state':'application_segment',
                    'provenance':'sqlite_source', 'quality':group[0][1].get('quality'),
                    'provider_final':False, 'speech_continuity_verified':False,
                    **({'source_revision':group[0][1]['source_revision']} if 'source_revision' in group[0][1] else {}),
                    'text':''.join(row['text'] for row,_ in group),
                    'record_ranges':[{'record_index':row['record_index'],
                        'char_start':0, 'char_end':len(row['text'])}
                        for row,_ in group]})
            group.clear()
        for row in catalog.values():
            locator = locators[row['record_index']]
            eligible = (locator.get('provenance') == 'sqlite_source'
                and locator.get('source_state') == 'application_segment'
                and locator.get('provider_final') is False and locator.get('ordering') == 'receipt_order'
                and isinstance(locator.get('capture_id'),str) and bool(locator['capture_id'])
                and type(locator.get('receipt_sequence')) is int and locator['receipt_sequence'] >= 1
                and type(locator.get('part_index')) is int and locator['part_index'] >= 0)
            if not eligible:
                flush()
                continue
            if group:
                previous, before = group[-1]
                same = all(before.get(key) == locator.get(key)
                    for key in ('capture_id','source_event_id','source_revision','quality'))
                adjacent = ((locator['receipt_sequence'] == before['receipt_sequence']
                        and locator['part_index'] == before['part_index']+1)
                    or (locator['receipt_sequence'] == before['receipt_sequence']+1
                        and locator['part_index'] == 0))
                if not (same and adjacent and row['record_index'] == previous['record_index']+1):
                    flush()
            group.append((row,locator))
        flush()
        return readings


    def _wire_payload(self, result, request):
        wire_result = {key: result[key] for key in
            ('meeting_id', 'version', 'available', 'completeness', 'history_status',
                'context_mode', 'context_scope', 'snapshot_sha256') if key in result}
        readings = []
        for source in result['selected_source_reading']:
            reading = {key: source[key] for key in ('record_index', 'text', 'provenance',
                'quality', 'provider_final', 'speech_continuity_verified', 'historical_context',
                'source_id', 'revision', 'source_revision') if key in source}
            if 'record_ranges' in source:
                ranges = source['record_ranges']
                reading['record_index_range_inclusive'] = [
                    ranges[0]['record_index'], ranges[-1]['record_index']]
            readings.append(reading)
        instruction = (
            'This full_snapshot replaces the previous meeting snapshot for this question. '
            'Use only these current source readings; earlier snapshots and prior assistant answers are not sources. '
            'Do not restore replaced revisions or removed records from earlier context. '
            'Different source disagreements remain disagreements; revision numbers are not a global fact ordering. '
            'Historical sources remain historical. If verbatim quotation is requested, '
            'return only the relevant current source text without an introduction, added quotation marks or explanation; '
            'otherwise answer naturally from the current sources. '
            'do not add greetings, imagined user replies or repeat the answer.')
        return _json({'tool':self.tool.name, 'result':wire_result,
            'selected_source_reading':readings,
            **request, 'instruction':instruction}) + '\n'


    def record_sent(self, plan, byte_count, *, session_id):
        self._scope(session_id)
        if (self._pending is None or self._pending['plan'] is not plan
                or type(byte_count) is not int or byte_count < 0
                or self._pending['returned'] + byte_count > self._pending['required']):
            raise ContextFailure('invalid_context_send_receipt')
        self._pending['returned'] += byte_count
        self.sent_bytes += byte_count

    def commit(self, plan, *, session_id):
        self._scope(session_id)
        if (self._pending is None or self._pending['plan'] is not plan
                or self._pending['returned'] != self._pending['required']):
            raise ContextFailure('context_send_incomplete')
        self._committed_records = self._pending['records']
        self._pending = None

    def status(self):
        return {'sent_bytes':self.sent_bytes,'total_limit_bytes':None,
            'committed_records':self._committed_records,'source_version':self._version,
            'pending':self._pending is not None,'model_consumption_verified':False,
            'preparing':self._preparing is not None,
            'delivery_scope':'successful_host_send_returns_this_live_thread'}
