"""Recorded command from the one completed directed diagnostic; do not auto-rerun."""
import asyncio
import json
import time
import unittest
from unittest.mock import patch
from teams_transcription import qa_probe
from test_qa_probe import ProbeTests

original = qa_probe.cleanup_probe
observations = []

async def observed(native, browser, owned, **kwargs):
    began = time.monotonic()
    operation = kwargs['operation_task']
    operation.add_done_callback(lambda task: observations.append({
        'event': 'operation_done', 'elapsed_ms': round((time.monotonic()-began)*1000, 3),
        'cancelled': task.cancelled()}))
    value = await original(native, browser, owned, **kwargs)
    observations.append({'event': 'cleanup_return',
        'elapsed_ms': round((time.monotonic()-began)*1000, 3),
        'receipt_pending_operation': value['pending_operation'],
        'operation_done': operation.done(),
        'pending_close_tasks': value['pending_close_tasks'],
        'reaped': value['reaped'], 'live_processes': value['live_processes'],
        'cleanup_status': value['status']})
    return value

suite = unittest.TestSuite([ProbeTests('test_real_native_start_shielded_close_cannot_delay_probe_cleanup')])
with patch.object(qa_probe, 'cleanup_probe', observed):
    result = unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({'directed_runs': 1, 'success': result.wasSuccessful(),
    'failures': len(result.failures), 'errors': len(result.errors),
    'observations': observations}, sort_keys=True))
