"""Deterministic old fixture timing counterexample, not the historical timeline."""
import json
from teams_transcription.b_question import ApplicationQuestionFramer

wall = [100.]
framer = ApplicationQuestionFramer(clock=lambda:wall[0])
wall[0] += .02
framer.push_pcm(b'\x00\x10'*480,started_at=wall[0]-.02,ended_at=wall[0])
framer.append_transcript('小白小白，合成問題？')
for _ in range(75):
    # Old wait_until creates each 20ms packet from its actual callback receipt.
    # A controlled 30ms caller lateness makes capture gaps 30ms (>20ms tolerance).
    wall[0] += .05
    framer.push_pcm(b'\0'*960,started_at=wall[0]-.02,ended_at=wall[0])
print(json.dumps({'callback_interval_seconds':.05,'packet_seconds':.02,
    'quiet_packets':75,'framing':framer.status()},sort_keys=True))
assert framer.poll() is not None, 'old receipt-anchored fixture cannot reach its required quiet barrier'
