"""One directed offline observation; unchanged fixture deadlines and assertions."""
import json
import time
import unittest
from unittest.mock import patch
from teams_transcription import qa_probe
from teams_transcription.b_native import NativeLiveResponder
from test_speech_completion_snapshot import SpeechCompletionSnapshotTests

events = []
origin = time.monotonic()

def event(kind, **values):
    if len(events) < 40:
        events.append({'event':kind,'elapsed_ms':round((time.monotonic()-origin)*1000,3),**values})

def scalars(native):
    framing = native.question_framer.status()
    pending = native.question_framer.pending_status()
    task = native._speech_task
    return {'phase':native._speech_completion_phase,'native_state':native.state,
        'done_is_set':native._speech_done.is_set(),'output_active':native.output.active,
        'speech_task_done':task.done() if task is not None else None,
        'native_error_present':native.error is not None,
        'input_counts':native.question_input.status()['counts'],
        'framing':{key:framing.get(key) for key in ('heard_activity','capture_recent',
            'followup_active','observed_quiet_seconds','emitted_requests')},
        'pending':{key:pending.get(key) for key in ('characters','has_wake','has_question')},
        'question_counts':native.question_receipts()['counts'],
        'rx_accepted_packets':native.rx_accepted_packets,'rx_peer_push_packets':native.rx_peer_push_packets}

actual_wait = qa_probe.wait_until
async def observed_wait(native, condition, timeout=45):
    event('inner_wait_begin',timeout_seconds=timeout,**scalars(native))
    seen_true = False
    def observed_condition():
        nonlocal seen_true
        value = condition()
        if value and not seen_true:
            seen_true = True
            event('inner_condition_true',**scalars(native))
        return value
    try:
        result = await actual_wait(native, observed_condition, timeout=timeout)
    except qa_probe.PhaseWaitTimeout as error:
        event('inner_wait_timeout',timeout_seconds=error.seconds,
            condition_seen_true=seen_true,**scalars(native))
        raise
    event('inner_wait_return',condition_seen_true=seen_true,**scalars(native))
    return result

actual_snapshot = NativeLiveResponder.speech_completion_snapshot
def observed_snapshot(native):
    result = actual_snapshot(native)
    event('speech_snapshot',**scalars(native))
    return result

actual_setattr = NativeLiveResponder.__setattr__
def observed_setattr(native, name, value):
    actual_setattr(native,name,value)
    if name == '_speech_completion_phase':
        event('phase_assignment',phase=value)

actual_writer = qa_probe.write_private_result
def observed_writer(path,evidence,**kwargs):
    receipt = evidence.get('control_receipt')
    if isinstance(receipt,dict):
        failure = receipt.get('failure') or {}
        event('private_receipt',failure_phase=failure.get('phase'),
            failure_code=failure.get('error_code'),timeout_seconds=failure.get('timeout_seconds'),
            owned_cleanup_verified=receipt.get('owned_cleanup_verified'))
    return actual_writer(path,evidence,**kwargs)

case = SpeechCompletionSnapshotTests('test_question_timeout_keeps_pending_media_snapshot_before_cleanup')
with patch.object(qa_probe,'wait_until',observed_wait), \
        patch.object(qa_probe,'write_private_result',observed_writer), \
        patch.object(NativeLiveResponder,'speech_completion_snapshot',observed_snapshot), \
        patch.object(NativeLiveResponder,'__setattr__',observed_setattr):
    result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
print(json.dumps({'directed_runs':1,'success':result.wasSuccessful(),
    'failures':len(result.failures),'errors':len(result.errors),'events':events},sort_keys=True))
